<?php
$plugin_url = plugin_dir_url( __FILE__ );	
wp_enqueue_style( 'slick_css', $plugin_url . 'assets/css/slick.css' );
wp_enqueue_style( 'owl_css', $plugin_url . 'assets/css/owl.carousel.css' );
wp_enqueue_style( 'nivo_css', $plugin_url . 'assets/css/nivo-slider.css' );
wp_enqueue_style( 'flaticon', $plugin_url . 'assets/css/flaticon.css' );
wp_enqueue_style( 'section_style', $plugin_url . 'assets/css/section-style.css' );
wp_enqueue_style( 'responsive_css', $plugin_url . 'assets/css/section-resposive.css' );

$plugin_url = plugin_dir_url( __FILE__ );
wp_enqueue_script('particles-js', $plugin_url . 'assets/js/particles.min.js', array('jquery',), null, true);
wp_enqueue_script('custom-animation', $plugin_url . 'assets/js/mouse-animation.js', array('jquery',), null, true);
wp_enqueue_script( 'tabscript', $plugin_url . 'assets/js/tabscript.js', array ( 'jquery' ), 1.1, true);
wp_enqueue_script( 'slick_js', $plugin_url . 'assets/js/slick.min.js', array ( 'jquery' ), 1.1, true);
wp_enqueue_script( 'owl_js', $plugin_url . 'assets/js/owl.carousel.min.js', array ( 'jquery' ), 1.1, true);
wp_enqueue_script( 'counter_js', $plugin_url . 'assets/js/jquery.counterup.min.js', array ( 'jquery' ), 1.1, true);
wp_enqueue_script( 'counter__waypoints', $plugin_url . 'assets/js/waypoints.min.js', array ( 'jquery' ), 1.1, true);
wp_enqueue_script( 'nivo_js', $plugin_url . 'assets/js/jquery.nivo.slider.pack.js', array ( 'jquery' ), 1.1, true);