document.addEventListener("DOMContentLoaded", function () {
    var particlesElement = document.getElementById("particles-banner-animate");

    if (!particlesElement) return; // If the div is not found, stop execution

    particlesJS("particles-banner-animate", {
        particles: {
            number: {
                value: 120,
                density: { enable: true, value_area: 800 }
            },
            color: { value: "#55C8FF" },
            shape: { type: "circle" },
            opacity: {
                value: 0.5,
                random: true,
                anim: { enable: false }
            },
            size: {
                value: 3,
                random: true,
                anim: { enable: false }
            },
            line_linked: {
                enable: true,
                distance: 150,
                color: "#55C8FF",
                opacity: 0.4,
                width: 1
            },
            move: {
                enable: true,
                speed: 3,
                direction: "none",
                random: false,
                straight: false,
                out_mode: "out",
                bounce: false
            }
        },
        interactivity: {
            detect_on: "canvas",
            events: {
                onhover: { enable: true, mode: "repulse" },
                onclick: { enable: true, mode: "push" }
            },
            modes: {
                repulse: { distance: 100, duration: 0.4 },
                push: { particles_nb: 4 }
            }
        },
        retina_detect: true
    });
});
