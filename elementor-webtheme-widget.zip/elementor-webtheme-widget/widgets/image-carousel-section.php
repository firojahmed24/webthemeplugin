<?php
if(!defined('ABSPATH')) exit;
class ImagecarouselSection extends \Elementor\Widget_Base{
	public function get_name(){
		return "images-carousel";
	}
	public function get_title(){
		return "Image Carousel";
	}
	public function get_icon(){
		return "eicon-button";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Images Number', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'list_title', [
				'label' => esc_html__( 'Title', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'List Title' , 'elementor-webtheme' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'image',
			[
				'label' => esc_html__( 'Choose Image', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Repeater List', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => esc_html__( 'Title One', 'elementor-webtheme' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'elementor-webtheme' ),
					],
					[
						'list_title' => esc_html__( 'Title Two', 'elementor-webtheme' ),
						'list_content' => esc_html__( 'Item content. Click the edit button to change this text.', 'elementor-webtheme' ),
					],
				],
				'title_field' => '{{{ list_title }}}',
			]
		);
	$this->end_controls_section();
/*--------- images carousel css start here  --------*/
		$this->start_controls_section(
			'section_option',
			[
				'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'select_option',
				[
					'label' => __( 'Select Your Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
					],
					'default' => 'one',
					
				]
			);
			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .image-carousel-section' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<?php if($settings['select_option']=='one'){ ?>
			<div class="image-carousel-section">
				<div class="img-carousel owl-carousel">
					<?php foreach (  $settings['list'] as $item ) { ?>
						<div class="img-number">
							<img src="<?php echo $item['image']['url']; ?>" alt="">
						</div>
					<?php } ?>
				</div>
			</div>
			<script>
				jQuery(document).ready(function($) {
					"use strict";

					$('.img-carousel').owlCarousel({
						items: 5,
						center: true,
						dots: true,
						nav: false,
						autoplayTimeout: 10000,
						navText: ["<i class='fa fa-long-arrow-left'></i>", "<i class='fa fa-long-arrow-right''></i>"],
						responsive: {
							0: {
								items: 1
							},
							768: {
								items: 2
							},
							992: {
								items: 3
							},
							1920: {
								items: 4
							}
						}
					});

				});
			</script>
		<?php }elseif($settings['select_option']=='two'){ ?>
			<div class="image-carousel-section option2">
				<div class="img-carousel2 owl-carousel">
					<?php foreach (  $settings['list'] as $item ) { ?>
						<div class="img-number">
							<img src="<?php echo $item['image']['url']; ?>" alt="">
						</div>
					<?php } ?>
				</div>
			</div>
			<script>
				jQuery(document).ready(function($) {
					"use strict";

					$('.img-carousel2').owlCarousel({
						items: 5,
						center: true,
						dots: true,
						nav: true,
						autoplayTimeout: 10000,
						navText: ["<i class='fa fa-long-arrow-left'></i>", "<i class='fa fa-long-arrow-right''></i>"],
						responsive: {
							0: {
								items: 1
							},
							768: {
								items: 1
							},
							992: {
								items: 1
							},
							1920: {
								items: 1
							}
						}
					});
				});
			</script>
		<?php } ?>
	<?php
	}
}