<?php
if(!defined('ABSPATH')) exit;
class PricingSection extends \Elementor\Widget_Base{
	public function get_name(){
		return "pricing_section";
	}
	public function get_title(){
		return "Pricing Section";
	}
	public function get_icon(){
		return "eicon-price-table";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls() {
		$this->start_controls_section(
			'package_section',
			[
				'label' => __( 'Pricing Content', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'single_img',
				[
				    'label' => esc_html__('Pricing Image','elementor-webtheme'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				]
			);
			$this->add_control(
				'name',
				[
					'label' => __( 'Pricing Title', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'Basic Price', 'elementor-webtheme' ),
					'placeholder' => __( 'Enter Title', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'title',
				[
					'label' => esc_html__( 'Pricing Title', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Pricing title', 'elementor-webtheme' ),
					'placeholder' => esc_html__( 'Type price title', 'elementor-webtheme' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'description',
				[
					'label' => esc_html__( 'Pricing Description', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 5,
					'default' => esc_html__( 'Pricing description', 'elementor-webtheme' ),
					'placeholder' => esc_html__( 'Type price description', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'dollar',
				[
					'label' => __( 'Price dollar', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '$', 'elementor-webtheme' ),
					'placeholder' => __( '$', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'price',
				[
					'label' => __( 'Price', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( '150', 'elementor-webtheme' ),
					'placeholder' => __( '150', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'date',
				[
					'label' => __( 'date', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => __( 'date', 'elementor-webtheme' ),
					'placeholder' => __( 'date', 'elementor-webtheme' ),
				]
			);
			$repeater = new \Elementor\Repeater();
			$repeater->add_control(
				'list_icon',
				[
					'label' => esc_html__( 'Price Icon', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'default' => [
						'value' => 'fas fa-check',
						'library' => 'fa-solid',
					],
					'recommended' => [
						'fa-solid' => [
							'circle',
							'dot-circle',
							'square-full',
						],
						'fa-regular' => [
							'circle',
							'dot-circle',
							'square-full',
						],
					],
				]
			);
			$repeater->add_control(
				'list_service', [
					'label' => esc_html__( 'Pricing Title', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Price List Title' , 'elementor-webtheme' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'services_list',
				[
					'label' => esc_html__( 'Price service List', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'list_service' => esc_html__( 'Pricing Service List One', 'elementor-webtheme' ),
						],
						[
							'list_service' => esc_html__( 'Pricing Service List Two', 'elementor-webtheme' ),
						],
					],
					'title_field' => '{{{ list_service }}}',
				]
			);
			$this->add_control(
				'show_active',
				[
					'label' => __( 'Active Table', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Yes', 'elementor-webtheme' ),
					'label_off' => __( 'No', 'elementor-webtheme' ),
					'return_value' => 'yes',
				]
			);
		$this->end_controls_section();
		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Pricing Button', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'button_text',
				[
					'label' => __( 'Button Text', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Know More', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Know More', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'button_link',
				[
					'label' => __( 'Button Link', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'elementor-webtheme' ),
				]
			);
		$this->end_controls_section();

	/*---------  Pricing Section css style start here  --------*/
	$this->start_controls_section(
		'section_option',
		[
			'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);
		$this->add_control(
			'select_option',
			[
				'label' => __( 'Select Your Option', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'one' => __( 'One', 'elementor-webtheme' ),
					'two' => __( 'Two', 'elementor-webtheme' ),
				],
				'default' => 'one',
				
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'title_description_style',
			[
				'label' => __( 'Title & Desc css ', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'title_heading',
				[
					'label' => esc_html__( 'Title css', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::HEADING,
				]
			);
			$this->add_control(
				'name_color',
				[
					'label' => __( 'Name Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-name h2' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'name_typography',
					'label' => __( 'Title Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .pricing-section .pricing-name h2',
				]
			);
			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-title h1' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'label' => __( 'Title Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .pricing-section .pricing-title h1',
				]
			);
			$this->add_responsive_control(
				'title_padding',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Title Padding', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-title h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Title Margin', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-title h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'description_heading',
				[
					'label' => esc_html__( 'Description css', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
			$this->add_control(
				'description_color',
				[
					'label' => __( 'Description Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing-section .description p' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'label' => __( 'Descr Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .pricing-section .description p',
				]
			);
			$this->add_responsive_control(
				'description_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Descr Margin', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing-section .description p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		$this->start_controls_section(
			'dollar_style',
			[
				'label' => __( 'Dollar css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'dollar_color',
				[
					'label' => __( 'Dollar Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-price-content .dollar' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'dollar_typography',
					'label' => __( 'Dollar Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .pricing-section .pricing-price-content .dollar',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'price_style',
			[
				'label' => __( 'Price css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'price_color',
				[
					'label' => __( 'Price Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-price-content .pricing-price' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'price_typography',
					'label' => __( 'Price Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .pricing-section .pricing-price-content .pricing-price',
				]
			);

		$this->end_controls_section();
		$this->start_controls_section(
			'date_style',
			[
				'label' => __( 'date css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'date_color',
				[
					'label' => __( 'date Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-price-content .price-date' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'date_typography',
					'label' => __( 'date Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .pricing-section .pricing-price-content .price-date',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'services_style',
			[
				'label' => __( 'services css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'service_color',
				[
					'label' => __( 'Cervice Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-content ul li' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'service_typography',
					'label' => __( 'Service Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .pricing-section .pricing-content ul li',
				]
			);
			$this->add_responsive_control(
				'service_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Service Margin', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-content ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__( 'Pricing Button css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'button_typography',
					'selector' => '{{WRAPPER}} .pricing-section .pricing-contact-button a',
				]
			);
			$this->start_controls_tabs(
				'style_tabs'
			);
			$this->start_controls_tab(
				'style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'text_color',
				[
					'label' => esc_html__( 'Button Text Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-contact-button a' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'background',
					'label' => esc_html__( 'Button BG', 'elementor-webtheme' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .pricing-section .pricing-contact-button a',
				]
			);

			$this->end_controls_tab();

			$this->start_controls_tab(
				'style_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'elementor-webtheme' ),
				]
			);

			$this->add_control(
				'text_hover_color',
				[
					'label' => esc_html__( 'Text Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-contact-button a:hover' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'hover_background',
					'label' => esc_html__( 'Button BG', 'elementor-webtheme' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .pricing-section .pricing-contact-button a:hover',
				]
			);

			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'button_border',
					'label' => esc_html__( 'Button Border', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .pricing-section .pricing-contact-button a',
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'button_border_radius',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Button Border Radius', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-contact-button a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'box_shadow',
					'label' => esc_html__( 'Button Box Shadow', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .pricing-section .pricing-contact-button a',
				]
			);
			$this->add_responsive_control(
				'button_padding',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Button Padding', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-contact-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'button_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Button Margin', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .pricing-section .pricing-contact-button a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

	}

	protected function render() {

		$settings = $this->get_settings_for_display();

		?>
		<?php if($settings['select_option']=='one'){ ?>
			<div class="pricing-section <?php if('yes' === $settings['show_active']){echo esc_attr('active');}?>">
				<?php if($settings['name']) : ?>
					<div class="pricing-name">
						<h2>
							<?php echo $settings['name']; ?>
						</h2>
					</div>
				<?php endif; ?>
				<?php if($settings['title']) : ?>
					<div class="pricing-title">
						<h1>
							<?php echo $settings['title']; ?>
						</h1>
					</div>
				<?php endif; ?>
				<div class="pricing-price-content">
					<?php if( !empty($settings['dollar']) ){ ?>
						<span class="dollar"><?php echo $settings['dollar']; ?></span>
					<?php } ?>	
					<?php if( !empty($settings['price']) ){ ?>
						<span class="pricing-price"><?php echo $settings['price']; ?></span>
					<?php } ?>		
					<?php if( !empty($settings['date']) ){ ?>
						<span class="price-date"><?php echo $settings['date']; ?></span>
					<?php } ?>	
				</div>
				<div class="pricing-content">
					<?php if($settings['single_img']['url']) : ?>
						<div class="pricing-img">
							<img src="<?php echo $settings['single_img']['url']; ?>" alt="" />
						</div>
					<?php endif; ?>
					<?php if($settings['button_text']) : ?>
						<div class="pricing-contact-button">
							<a href="<?php echo esc_url($settings['button_link']['url']); ?>"
							class="pricing-button"><?php echo $settings['button_text']; ?></a>
						</div>
					<?php endif; ?>
					<ul class="pricing-services-list">																	
						<?php foreach (  $settings['services_list'] as $item ) { ?>
							<li>
								<?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
								<?php echo $item['list_service']; ?>
							</li>
						<?php } ?>														
					</ul>
				</div>
			</div>

		<?php }elseif($settings['select_option']=='two'){ ?>
			<div class="pricing-section option2 <?php if('yes' === $settings['show_active']){echo esc_attr('active');}?>">
			    <div class="pricing-name">
					<h2>
						<?php echo $settings['name']; ?>
					</h2>
				</div>
				<div class="pricing-img">
					<img src="<?php echo $settings['single_img']['url']; ?>" alt="" />
				</div>
				<div class="pricing-content">
					<div class="pricing-title">
						<h1>
							<?php echo $settings['title']; ?>
						</h1>
					</div>
					<div class="pricing-price-content">
						<?php if( !empty($settings['dollar']) ){ ?>
							<span class="dollar"><?php echo $settings['dollar']; ?></span>
						<?php } ?>	
						<?php if( !empty($settings['price']) ){ ?>
							<span class="pricing-price"><?php echo $settings['price']; ?></span>
						<?php } ?>		
						<?php if( !empty($settings['date']) ){ ?>
							<span class="price-date"><?php echo $settings['date']; ?></span>
						<?php } ?>	
					</div>
					<ul class="pricing-services-list">																	
						<?php foreach (  $settings['services_list'] as $item ) { ?>
							<li>
								<?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
								<?php echo $item['list_service']; ?>
							</li>
						<?php } ?>														
					</ul>
					<div class="pricing-contact-button">
						<a href="<?php echo esc_url($settings['button_link']['url']); ?>"
					 	class="pricing-button"><?php echo $settings['button_text']; ?></a>
					</div>
				</div>
			</div>
		<?php }?>
		<?php
	}
}