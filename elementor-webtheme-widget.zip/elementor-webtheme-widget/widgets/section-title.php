<?php
if(!defined('ABSPATH')) exit;
class SectionTitles extends \Elementor\Widget_Base{
	public function get_name(){
		return "main-title-area";
	}
	public function get_title(){
		return "Section Title";
	}
	public function get_icon(){
		return "eicon-t-letter";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
		$this->start_controls_section(
			'text_section',
			[
				'label' => __( 'Section Title Text', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'section_subtitle',
				[
					'label' => __( 'Subtitle', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter subtitle', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Section Subtitle', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'section_title_one',
				[
					'label' => __( 'Title One', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter title One', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Section Title One', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'section_title_two',
				[
					'label' => __( 'Title Two', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter Title Two', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Section Title Two', 'elementor-webtheme' ),
				]
			);
				$this->add_control(
				'section_brandcolor_title',
				[
					'label' => __( 'Brandcolor Title', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter brandcolor Title', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Brandcolor Title', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'section_description',
				[
					'label' => __( 'Description', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter Description', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'This is Section Default Description.You can change it.', 'elementor-webtheme' ),
				]
			);
		$this->end_controls_section();

/*---------  Section Title css style start here  --------*/

		$this->start_controls_section(
			'section_option',
			[
				'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'select_option',
				[
					'label' => __( 'Select Your Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
						'three' => __( 'Three', 'elementor-webtheme' ),
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
						'four' => __( 'Four', 'elementor-webtheme' ),

					],
					'default' => 'one',
				]
			);
			$this->add_responsive_control(
				'text_align_center',
				[
					'label' => esc_html__( 'Alignment', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => esc_html__( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => esc_html__( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => esc_html__( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
					],
					'toggle' => true,
					'selectors' => [
						'{{WRAPPER}} .main-title-area' => 'text-align: {{VALUE}};',
					]
				]
			);
			$this->add_responsive_control(
				'width',
				[
					'type' => \Elementor\Controls_Manager::SLIDER,
					'label' => esc_html__( 'Width', 'elementor-webtheme' ),
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'devices' => [ 'desktop', 'tablet', 'mobile' ],
					'selectors' => [
						'{{WRAPPER}} .main-title-area' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'subtitle_style',
			[
				'label' => __( 'Subtitle css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'subtitle_color',
				[
					'label' => __( 'SubTitle Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-subtitle h3' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'subtitle_typography',
					'label' => __( 'Subtitle Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .main-title-area .section-subtitle h3',
				]
			);
			$this->add_responsive_control(
				'subtitle_padding',
				[
					'label' => __( 'Subtitle Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-subtitle h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'subtitle_margin',
				[
					'label' => __( 'Subtitle Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-subtitle h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => __( 'Title One css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-title-one h1' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'label' => __( 'Title Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .main-title-area .section-title-one h1',
				]
			);
			$this->add_responsive_control(
				'title_padding',
				[
					'label' => __( 'Title Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-title-one h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Title Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-title-one h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			
		$this->end_controls_section();

			$this->start_controls_section(
				'title_two_style',
				[
					'label' => __( 'Title Two css', 'elementor-webtheme' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);
				$this->add_control(
				'title_two_color',
				[
					'label' => __( 'Title Two Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-title-two h1' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_two_typography',
					'label' => __( 'Title Two Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .main-title-area .section-title-two h1',
				]
			);
			$this->add_responsive_control(
				'title_two_padding',
				[
					'label' => __( 'Title Two Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-title-two h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'title_two_margin',
				[
					'label' => __( 'Title Two Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-title-two h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'brandcolor_style',
			[
				'label' => __( 'Brandcolor css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'brandcolor_text_color',
				[
					'label' => __( 'Brandcolor Text Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .main-title-area span.section-brandcolor-title' => 'color: {{VALUE}}',
					],
					'separator' => 'before',
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'brandcolor_text_typography',
					'label' => __( 'Brandcolor Text Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .main-title-area span.section-brandcolor-title',
				]
			);
			$this->add_responsive_control(
				'brandcolor_padding',
				[
					'label' => __( 'Title Two Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .main-title-area span.section-brandcolor-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'description_style',
			[
				'label' => __( 'Description css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'description_color',
				[
					'label' => __( 'Description Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-description p' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'label' => __( 'Description Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .main-title-area .section-description p',
				]
			);
			$this->add_responsive_control(
				'description_padding',
				[
					'label' => __( 'Description padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-description p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'description_margin',
				[
					'label' => __( 'Description Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .main-title-area .section-description p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
	}
	protected function render(){
		$settings = $this->get_settings_for_display();
		?>
		<?php if($settings['select_option']=='one'){ ?>
			<div class="main-title-area option1">
				<?php if(!empty($settings['section_subtitle'])) { ?>
					<div class="section-subtitle">
						<h3><?php echo $settings['section_subtitle']; ?></h3>
					</div>
				<?php } ?>
				<?php if(!empty($settings['section_title_one'])) { ?> 
					<div class="section-title-one">
						<h1><?php echo $settings['section_title_one']; ?></h1>
					</div>
				<?php } ?>
				<div class="section_brandcolor_title">
				<?php if(!empty($settings['section_title_two'])) { ?>
					<div class="section-title-two">
						<h1><?php echo $settings['section_title_two']; ?> 
						<span class="section-brandcolor-title"><?php echo $settings['section_brandcolor_title']; ?></span></h1>
					</div>
				<?php } ?>
				</div>
				<?php if(!empty($settings['section_description'])) { ?> 
					<div class="section-description">
						<p><?php echo $settings['section_description']; ?></p>
					</div>
				<?php } ?>
			</div>
		<?php }elseif($settings['select_option']=='two'){ ?>
			<div class="main-title-area option2">
				<?php if(!empty($settings['section_subtitle'])) { ?>
					<div class="section-subtitle">
						<h3><?php echo $settings['section_subtitle']; ?></h3>
					</div>
					<?php } ?>
					<?php if(!empty($settings['section_title_one'])) { ?> 
						<div class="section-title-one">
							<h1><?php echo $settings['section_title_one']; ?></h1>
						</div>
					<?php } ?>
					<?php if(!empty($settings['section_title_two'])) { ?>
						<div class="section-title-two">
							<h1><?php echo $settings['section_title_two']; ?> 
							<span class="section-brandcolor-title"><?php echo $settings['section_brandcolor_title']; ?></span></h1>
						</div>
					<?php } ?>
					<?php if(!empty($settings['section_description'])) { ?> 
						<div class="section-description">
							<p><?php echo $settings['section_description']; ?></p>
						</div>
					<?php } ?>
				</div>
			<?php }elseif($settings['select_option']=='three'){ ?>
				<div class="main-title-area option3">
					<?php if(!empty($settings['section_subtitle'])) { ?>
						<div class="section-subtitle">
							<h3><?php echo $settings['section_subtitle']; ?></h3>
						</div>
					<?php } ?>
					<?php if(!empty($settings['section_title_one'])) { ?> 
						<div class="section-title-one">
							<h1><?php echo $settings['section_title_one']; ?></h1>
						</div>
					<?php } ?>
					<?php if(!empty($settings['section_title_two'])) { ?>
						<div class="section-title-two">
							<h1><?php echo $settings['section_title_two']; ?> 
							<span class="section-brandcolor-title"><?php echo $settings['section_brandcolor_title']; ?></span></h1>
						</div>
					<?php } ?>
					<?php if(!empty($settings['section_description'])) { ?> 
						<div class="section-description">
							<p><?php echo $settings['section_description']; ?></p>
						</div>
					<?php } ?>
				</div>
			<?php }elseif($settings['select_option']=='four'){ ?>
				<div class="main-title-area option4">
					<?php if(!empty($settings['section_subtitle'])) { ?>
						<div class="section-subtitle">
							<h3><?php echo $settings['section_subtitle']; ?></h3>
						</div>
					<?php } ?>
					<?php if(!empty($settings['section_title_one'])) { ?> 
						<div class="section-title-one">
							<h1><?php echo $settings['section_title_one']; ?></h1>
						</div>
					<?php } ?>
					<?php if(!empty($settings['section_title_two'])) { ?>
						<div class="section-title-two">
							<h1><?php echo $settings['section_title_two']; ?> </h1>
						</div>
						<span class="section-brandcolor-title"><?php echo $settings['section_brandcolor_title']; ?></span>
					<?php } ?>
					<?php if(!empty($settings['section_description'])) { ?> 
						<div class="section-description">
							<p><?php echo $settings['section_description']; ?></p>
						</div>
					<?php } ?>
				</div>
			<?php }?>
		<?php 
	}
}