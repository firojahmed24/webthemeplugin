<?php
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
if(!defined('ABSPATH')) exit;
class SocialMediaSection extends \Elementor\Widget_Base {
	public function get_name() {
		return 'socialmedia';
	}
	public function get_title() {
		return __( 'Social Media', 'elementor-webtheme' );
	}
	public function get_icon() {
		return 'eicon-social-icons';
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls() {
		$this->start_controls_section(
			'social_link_section',
			[
				'label' => __( 'Social Media List', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'list_title', [
				'label' => __( 'Social Title', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => __( 'Social List Title' , 'elementor-webtheme' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'social_icon',
			[
				'label' => esc_html__( 'Media Icon', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::ICONS,
			]
		);
		$repeater->add_control(
			'website_link',
			[
				'label' => __( 'Media Link', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => __( 'https://your-link.com', 'elementor-webtheme' ),
				'show_external' => true,
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
			]
		);
		$this->add_control(
			'list',
			[
				'label' => __( 'Social Media List', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'list_title' => __( 'Facebook', 'elementor-webtheme' ),
						'website_link' => __( 'You Can Chance it.', 'elementor-webtheme' ),
					],
					[
						'list_title' => __( 'Linkedin', 'elementor-webtheme' ),
						'website_link' => __( 'You Can Chance it.', 'elementor-webtheme' ),
					],
				],
				'title_field' => '{{{ list_title }}}',
			]
		);

		$this->end_controls_section();

/*---------  Section Title css style start here  --------*/

		$this->start_controls_section(
			'section_option',
			[
				'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'select_option',
				[
					'label' => __( 'Select Your Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
					],
					'default' => 'one',
					
				]
			);
			$this->add_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'default' => 'center',
					'toggle' => true,
					'selectors' => [
					'{{WRAPPER}} .social-media-section' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'title_section',
			[
				'label' => __( 'Title css', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->start_controls_tabs(
				'title_style_tabs'
			);
				$this->start_controls_tab(
					'title_style_normal_tab',
					[
						'label' => __( 'Normal', 'elementor-webtheme' ),
					]
				);
				
					$this->add_control(
						'title_color',
						[
							'label' => __( 'Title Color', 'elementor-webtheme' ),
							'type' => Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .social-media-section ul li a' => 'color: {{VALUE}}',
							],
						]
					);
				
				$this->end_controls_tab();
				
				$this->start_controls_tab(
					'title_style_hover_tab',
					[
						'label' => __( 'Hover', 'elementor-webtheme' ),
					]
				);

					$this->add_control(
						'hover_title_color',
						[
							'label' => __( 'Color', 'elementor-webtheme' ),
							'type' => Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .social-media-section ul li a:hover' => 'color: {{VALUE}}',
							],
						]
					);
				
				$this->end_controls_tab();
				
			$this->end_controls_tabs();

			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Title Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .social-media-section ul li a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .social-media-section ul li a',
				]
			);

		$this->end_controls_section();
		$this->start_controls_section(
			'icon_style',
			[
				'label' => __( 'Media Icon css', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'icon_color',
				[
					'label' => __( 'Icon Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .social-media-section ul li a' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'background',
					'label' => esc_html__( 'Background', 'elementor-webtheme' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .social-media-section ul li a',
				]
			);

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'icon_typography',
					'selector' => '{{WRAPPER}} .social-media-section ul li a',
				]
			);
		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<?php if($settings['select_option']=='one'){ ?>
		<div class="social-media-section">
			<ul>
				<?php foreach (  $settings['list'] as $item ) { ?>
				<li><a href="<?php echo esc_url($item['website_link']['url']); ?>">
					<?php \Elementor\Icons_Manager::render_icon( $item['social_icon'], [ 'aria-hidden' => 'true' ] ); ?>
				</a></li>
				<?php } ?>
			</ul>
		</div>
		<?php }elseif($settings['select_option']=='two'){ ?>
		<div class="social-media-section option2">
			<ul>
				<?php foreach (  $settings['list'] as $item ) { ?>
				<li><a href="<?php echo esc_url($item['website_link']['url']); ?>"><?php echo $item['list_title']; ?></a></li>
				<?php } ?>
			</ul>
		</div>

		<?php } ?>
		<?php
	}
}