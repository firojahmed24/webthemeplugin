<?php
if(!defined('ABSPATH')) exit;
class IconListSection extends \Elementor\Widget_Base {
	public function get_name() {
		return 'icon_list_section';
	}
	public function get_title() {
		return esc_html__( 'Icon List Section', 'elementor-webtheme' );
	}
	public function get_icon() {
		return 'eicon-bullet-list';
	}
	public function get_categories() {
		return [ 'elementor-webtheme-category' ];
	}
	public function get_keywords() {
		return [ 'list', 'ul', 'ol' ];
	}
	protected function register_controls() {
		$this->start_controls_section(
			'list_content',
			[
				'label' => esc_html__( 'Icon List Section', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$repeater = new \Elementor\Repeater();
			$repeater->add_control(
				'list_icon',
				[
					'label' => esc_html__( 'Icon List', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'default' => [
						'value' => 'fas fa-check',
						'library' => 'fa-solid',
					],
				]
			);
			$repeater->add_control(
				'list_title', [
					'label' => esc_html__( 'Icon List Title', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Icon List Title' , 'elementor-webtheme' ),
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'list_link',
				[
					'label' => esc_html__( 'Icon List Link', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => esc_html__( 'https://your-link.com', 'elementor-webtheme' ),
					'options' => [ 'url', 'is_external', 'nofollow' ],
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
					'label_block' => true,
				]
			);
			$this->add_control(
				'list',
				[
					'label' => esc_html__( 'Repeater List', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'list_title' => esc_html__( 'Icon List Title One', 'elementor-webtheme' ),
							'list_content' => esc_html__( 'Click & You can chance it', 'elementor-webtheme' ),
						],
						[
							'list_title' => esc_html__( 'Icon List Title Two', 'elementor-webtheme' ),
							'list_content' => esc_html__( 'Click & You can chance it', 'elementor-webtheme' ),
						],
						[
							'list_title' => esc_html__( 'Icon List Title Three', 'elementor-webtheme' ),
							'list_content' => esc_html__( 'Click & Chance text', 'elementor-webtheme' ),
						],
					],
					'title_field' => '{{{ list_title }}}',
				]
			);
		$this->end_controls_section();
		/*---------  Icon box css style start here  --------*/
		$this->start_controls_section(
			'section_option',
			[
				'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'select_option',
				[
					'label' => __( 'Select Your Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
					],
					'default' => 'one',
					
				]
			);
			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .single-list-content' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'icon_section_style',
			[
				'label' => __( 'Icon css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'style_tabs'
		);
		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => __( 'Normal', 'elementor-webtheme' ),
			]
		);

			$this->add_control(
				'icon_color',
				[
					'label' => __( 'Icon Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .single-list-content li i' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'icon_background_color',
					'label' => esc_html__( 'Background', 'elementor-webtheme' ),
					'types' => [ 'classic', 'gradient' ],
					'fields_options' => [
						'color' => [
							'selectors' => [
								'{{SELECTOR}}' => 'background: {{VALUE}};',
							],
						]
					],
					'selector' => '{{WRAPPER}} .single-list-content li i',
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'icon_border',
					'label' => __( 'Border', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .single-list-content li i',
				]
			);
			$this->add_responsive_control(
				'icon_border_radius',
				[
					'label' => __( 'Icon Border Radius', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-list-content li i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_tab();

		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => __( 'Hover', 'elementor-webtheme' ),
			]
		);

			$this->add_control(
				'hover_icon_color',
				[
					'label' => __( 'Icon Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .single-list-content li:hover i' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'hover_icon_background_color',
					'label' => esc_html__( 'Background', 'elementor-webtheme' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .single-list-content li:hover i',
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'hover_border',
					'label' => __( 'Hover Border', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .single-list-content li:hover i',
				]
			);
			$this->add_responsive_control(
				'hover_icon_border_radius',
				[
					'label' => __( 'Icon Border Radius', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-list-content li:hover i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_tab();

		$this->end_controls_tabs();

			$this->add_responsive_control(
				'icon_margin',
				[
					'label' => __( 'Icon Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-list-content li i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'height',
				[
					'label' => __( 'Height', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .single-list-content li i' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'width',
				[
					'label' => __( 'Width', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .single-list-content li i' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'icon_typography',
					'selector' => '{{WRAPPER}} .single-list-content li i',
				]
			);
			
		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'title_color',
				[
					'label' => esc_html__( 'Title Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-list-content li span' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .single-list-content li span',
				]
			);
			$this->add_responsive_control(
				'title_padding',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Title Padding', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-list-content li span' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Title Margin', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-list-content li span' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<?php if($settings['select_option']=='one'){ ?>
			<div class="list-section">
				<ul class="single-list-content">
					<?php foreach (  $settings['list'] as $item ) { ?>
						<li>
							<?php if( !empty($item['list_link']['url']) ){ echo '<a href="'.esc_url($item['list_link']['url']).'">'; } ?>
								<?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
								<span><?php echo $item['list_title']; ?></span>
							<?php if( !empty($item['list_link']['url']) ){ echo '</a>'; } ?>
						</li>
					<?php } ?>
				</ul>
			</div>
		<?php }elseif($settings['select_option']=='two'){ ?>
			<div class="list-section option2">
				<ul class="single-list-content">
					<?php foreach (  $settings['list'] as $item ) { ?>
						<li>
							<?php if( !empty($item['list_link']['url']) ){ echo '<a href="'.esc_url($item['list_link']['url']).'">'; } ?>
								<?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], [ 'aria-hidden' => 'true' ] ); ?>
								<span><?php echo $item['list_title']; ?></span>
							<?php if( !empty($item['list_link']['url']) ){ echo '</a>'; } ?>
						</li>
					<?php } ?>
				</ul>
			</div>
		<?php } ?>
		<?php
	}
}