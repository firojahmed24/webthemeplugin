<?php
use Elementor\Group_Control_Typography;
if(!defined('ABSPATH')) exit;
class IconBoxSection extends \Elementor\Widget_Base {
	public function get_name() {
		return 'iconboxsection';
	}
	public function get_title() {
		return __( 'Icon Box Section', 'elementor-webtheme' );
	}
	public function get_icon() {
		return 'eicon-icon-box';
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls() {
		$this->start_controls_section(
			'icon_section',
			[
				'label' => __( 'Icon or Img', 'elementor-webtheme' ),
			]
		);
			$this->add_control(
				'icons_type',
				[
				    'label' => esc_html__('Icon Type','elementor-webtheme'),
				    'type' => \Elementor\Controls_Manager::CHOOSE,
				    'options' =>[
					  'img' =>[
						'title' =>esc_html__('Image','elementor-webtheme'),
						'icon' =>'fa fa-picture-o',
					  ],
					  'icon' =>[
						'title' =>esc_html__('Icon','elementor-webtheme'),
						'icon' =>'fa fa-info',
					  ]
				    ],
				    'default' => 'icon',
				]
			 );
			 $this->add_control(
				'select_icon',
				[
					'label' => esc_html__( 'Select Icon', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'condition'=>[
						'icons_type'=> 'icon',
					],
					'label_block' => true,
				]
			);
			$this->add_control(
				'select_img',
				[
				    'label' => esc_html__('Select Image','elementor-webtheme'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				    'condition' => [
					  'icons_type' => 'img',
				    ]
				]
			);
		$this->end_controls_section();
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Box Text', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'number_text',
			[
				'label' => __( 'Number', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your number', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( '01', 'elementor-webtheme' ),
				'condition' => [
					  'select_option' => 'two',
				    ]
			]
		);
			$this->add_control(
				'title_text',
				[
					'label' => __( 'Title', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your title', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Icon Box Title', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'description_text',
				[
					'label' => __( 'Description', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter your paragraph', 'elementor-webtheme' ),
					'default' => __( 'Icon Box Description The company will produce 8,000 tonnes of printed materials', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'show_active',
				[
					'label' => __( 'Active Icon Box', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Yes', 'elementor-webtheme' ),
					'label_off' => __( 'No', 'elementor-webtheme' ),
					'return_value' => 'yes',
				]
			);
		$this->end_controls_section();

/*---------  Icon box css style start here  --------*/
		$this->start_controls_section(
			'section_option',
			[
				'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'select_option',
				[
					'label' => __( 'Select Your Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
						'three' => __( 'Three', 'elementor-webtheme' ),
					],
					'default' => 'one',
					
				]
			);
			$this->add_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'fa fa-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'fa fa-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'fa fa-align-right',
						],
					],
					'toggle' => true,
					'selectors' => [
					'{{WRAPPER}} .icon-box-section' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'single_box_section_style',
			[
				'label' => __( 'Single Box css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'single_box_bg_color',
			[
				'label' => __( 'Single Box BG Color', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .icon-box-section' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'hover_single_bg_color',
			[
				'label' => __( 'Hover Box BG Color', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .icon-box-section:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'single_border',
				'label' => __( 'Single Box Border', 'elementor-webtheme' ),
				'selector' => '{{WRAPPER}} .icon-box-section',
			]
		);
		$this->add_responsive_control(
			'single_border_radius',
			[
				'label' => __( 'Box Border Radius', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .icon-box-section' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'hover_single_border',
				'label' => __( 'Hover Box Border', 'elementor-webtheme' ),
				'selector' => '{{WRAPPER}} .icon-box-section:hover',
			]
		);
		$this->add_responsive_control(
			'hover_box_border_radius',
			[
				'label' => __( 'Hover Box Border Radius', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .icon-box-section:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'single_box_padding',
			[
				'label' => __( 'Single Box Padding', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .icon-box-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'single_box_margin',
			[
				'label' => __( 'Single Box Margin', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .icon-box-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'icon_section_style',
			[
				'label' => __( 'Icon css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs(
			'style_tabs'
		);
			$this->start_controls_tab(
				'style_normal_tab',
				[
					'label' => __( 'Normal', 'elementor-webtheme' ),
				]
			);
			/*---------  Icon css start here  --------*/
				$this->add_control(
					'icon_color',
					[
						'label' => __( 'Icon Color', 'elementor-webtheme' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .icon-box-icon i' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'icon_background_color',
					[
						'label' => __( 'Background Color', 'elementor-webtheme' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .icon-box-icon i' => 'background: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'icon_border',
						'label' => __( 'Icon Border', 'elementor-webtheme' ),
						'selector' => '{{WRAPPER}} .icon-box-icon i',
					]
				);
				$this->add_responsive_control(
					'icon_border_radius',
					[
						'label' => __( 'Border Radius', 'elementor-webtheme' ),
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', 'em', '%' ],
						'selectors' => [
							'{{WRAPPER}} .icon-box-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							'{{WRAPPER}} .small-img img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
			$this->end_controls_tab();
			
			$this->start_controls_tab(
				'style_hover_tab',
				[
					'label' => __( 'icon Hover', 'elementor-webtheme' ),
				]
			);

				$this->add_control(
					'icon_hover_color',
					[
						'label' => __( 'Icon Hover Color', 'elementor-webtheme' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .icon-box-section:hover .icon-box-icon i' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_control(
					'hover_icon_background_color',
					[
						'label' => __( 'Icon Background Color', 'elementor-webtheme' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .icon-box-section:hover .icon-box-icon i' => 'background: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'hover_border',
						'label' => __( 'Icon Hover Border', 'elementor-webtheme' ),
						'selector' => '{{WRAPPER}} .icon-box-section:hover .icon-box-icon i',
					]
				);
				$this->add_responsive_control(
					'hover_icon_border_radius',
					[
						'label' => __( 'Icon Border Radius', 'elementor-webtheme' ),
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'size_units' => [ 'px', 'em', '%' ],
						'selectors' => [
							'{{WRAPPER}} .icon-box-section:hover .icon-box-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
			$this->end_controls_tab();
			
		$this->end_controls_tabs();

			$this->add_responsive_control(
				'icon_padding',
				[
					'label' => __( 'Icon Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .icon-box-section .icon-box-icon i' => 'Padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'icon_margin',
				[
					'label' => __( 'Icon Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .icon-box-section .icon-box-icon' => 'Margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'icon_typography',
					'selector' => '{{WRAPPER}} .icon-box-icon i',
				]
			);/*---------  Icon css end here  --------*/
		$this->end_controls_section();

		/*---------  Title css start here  --------*/
		$this->start_controls_section(
			'title_section',
			[
				'label' => __( 'Title css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->start_controls_tabs(
				'title_style_tabs'
			);
				$this->start_controls_tab(
					'title_style_normal_tab',
					[
						'label' => __( 'Normal', 'elementor-webtheme' ),
					]
				);
					$this->add_control(
						'title_color',
						[
							'label' => __( 'Tile Color', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .icon-box-section .icon-box-title h2' => 'color: {{VALUE}}',
							],
						]
					);
				$this->end_controls_tab();
				$this->start_controls_tab(
					'title_style_hover_tab',
					[
						'label' => __( 'Title Hover', 'elementor-webtheme' ),
					]
				);
					$this->add_control(
						'hover_title_color',
						[
							'label' => __( 'Title Color', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .icon-box-section:hover .icon-box-title h2' => 'color: {{VALUE}}',
							],
						]
					);
				$this->end_controls_tab();
			$this->end_controls_tabs();
			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Title Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .icon-box-section .icon-box-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_one_typography',
					'selector' => '{{WRAPPER}} .icon-box-section .icon-box-title h2',
				]
			);/*---------  Title css end here  --------*/
		$this->end_controls_section();

		/*---------  Description css start here  --------*/
		$this->start_controls_section(
			'description_section',
			[
				'label' => __( 'Description css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->start_controls_tabs(
				'description_style_tabs'
			);
				$this->start_controls_tab(
					'description_style_normal_tab',
					[
						'label' => __( 'Normal', 'elementor-webtheme' ),
					]
				);
    			$this->add_control(
    				'description_color',
    				[
    					'label' => __( 'Description Color', 'elementor-webtheme' ),
    					'type' => \Elementor\Controls_Manager::COLOR,
    					'default' => '',
    					'selectors' => [
    						'{{WRAPPER}} .icon-box-description p' => 'color: {{VALUE}}',
    					],
    				]
    			);
				$this->end_controls_tab();
				$this->start_controls_tab(
					'description_style_hover_tab',
					[
						'label' => __( 'Desc Hover', 'elementor-webtheme' ),
					]
				);
					$this->add_control(
						'hover_description_color',
						[
							'label' => __( 'Desc Color', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .icon-box-section:hover .icon-box-description p' => 'color: {{VALUE}}',
							],
						]
					);
				$this->end_controls_tab();
			$this->end_controls_tabs();
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'selector' => '{{WRAPPER}} .icon-box-description p',
				]
			);/*---------  Description css end here  --------*/
		$this->end_controls_section();

/*---------  Box css start here  --------*/
		$this->start_controls_section(
			'box_section_style',
			[
				'label' => __( 'Icon Box css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->start_controls_tabs(
				'box_style_tabs'
			);
				$this->start_controls_tab(
					'box_style_normal_tab',
					[
						'label' => __( 'Normal', 'elementor-webtheme' ),
					]
				);
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'box_border',
							'label' => __( 'Box Border', 'elementor-webtheme' ),
							'selector' => '{{WRAPPER}} .icon-box-section',
						]
					);
					$this->add_responsive_control(
						'box_border_radius',
						[
							'label' => __( 'Box Border Radius', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .icon-box-section' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'box_shadow',
							'label' => __( 'Box Shadow', 'elementor-webtheme' ),
							'selector' => '{{WRAPPER}} .icon-box-section',
						]
					);
					$this->add_group_control(
						\Elementor\Group_Control_Background::get_type(),
						[
							'name' => 'box_background',
							'label' => __( 'Box Background', 'elementor-webtheme' ),
							'types' => [ 'classic', 'gradient', 'video' ],
							'selector' => '{{WRAPPER}} .icon-box-section',
						]
					);
				$this->end_controls_tab();
				$this->start_controls_tab(
					'box_style_hover_tab',
					[
						'label' => __( 'Box Hover', 'elementor-webtheme' ),
					]
				);
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'hover_box_border',
							'label' => __( 'Box Border', 'elementor-webtheme' ),
							'selector' => '{{WRAPPER}} .icon-box-section:hover',
						]
					);
					$this->add_responsive_control(
						'hover_box_border_radius',
						[
							'label' => __( 'Box Border Radius', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .icon-box-section:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'hover_box_shadow',
							'label' => __( 'Box Shadow', 'elementor-webtheme' ),
							'selector' => '{{WRAPPER}} .icon-box-section:hover',
						]
					);
					$this->add_group_control(
						\Elementor\Group_Control_Background::get_type(),
						[
							'name' => 'hover_box_background',
							'label' => __( 'Box Background', 'elementor-webtheme' ),
							'types' => [ 'classic', 'gradient', 'video' ],
							'selector' => '{{WRAPPER}} .icon-box-section:hover',
						]
					);
				
				$this->end_controls_tab();
			$this->end_controls_tabs();
			$this->add_responsive_control(
				'box_margin',
				[
					'label' => __( 'Box Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .icon-box-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'box_padding',
				[
					'label' => __( 'Box Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .icon-box-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);/*---------  Box css end here  --------*/
		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<?php if($settings['select_option']=='one'){ ?>
		<div class="icon-box-section option1 <?php if('yes' === $settings['show_active']){echo esc_attr('active');}?>">
			<div class="icon-box-icon-content">
				<?php if($settings['icons_type'] == 'icon' ) : ?>
				<div class="icon-box-icon">
					<i class="<?php echo esc_attr($settings['select_icon']['value']); ?>"></i>
				</div>
				<?php else: ?>
				<div class="small-img">
					<img src="<?php echo $settings['select_img']['url'];?>" alt="" />
				</div>
				<?php endif; ?>
			</div>
			<div class="icon-box-text-content">
				<div class="icon-box-title">
					<h2><?php echo $settings['title_text']; ?></h2>
				</div>
				<div class="icon-box-description">
					<p><?php echo $settings['description_text']; ?></p>
				</div>
			</div>
		</div>
		<?php }elseif($settings['select_option']=='two'){ ?>
		<div class="icon-box-section option2">
			<div class="icon-box-icon-content">
				<?php if($settings['icons_type'] == 'icon' ) : ?>
				<div class="icon-box-icon">
					<i class="<?php echo esc_attr($settings['select_icon']['value']); ?>"></i>
				</div>
				<?php else: ?>
				<div class="small-img">
					<img src="<?php echo $settings['select_img']['url'];?>" alt="" />
				</div>
				<?php endif; ?>
			</div>
			<div class="icon-box-text-content">
				<?php if($settings['number_text']) : ?>
					<div class="icon-box-number">
						<h2><?php echo $settings['number_text']; ?></h2>
					</div>
				<?php endif; ?>
				<?php if($settings['title_text']) : ?>
					<div class="icon-box-title">
						<h2><?php echo $settings['title_text']; ?></h2>
					</div>
				<?php endif; ?>
				<?php if($settings['description_text']) : ?>
					<div class="icon-box-description">
						<p><?php echo $settings['description_text']; ?></p>
					</div>
				<?php endif; ?>
			</div>
		</div>
		<?php }elseif($settings['select_option']=='three'){ ?>
		<div class="icon-box-section option3">
			<div class="icon-box-icon-content">
				<?php if($settings['icons_type'] == 'icon' ) : ?>
				<div class="icon-box-icon">
					<i class="<?php echo esc_attr($settings['select_icon']['value']); ?>"></i>
				</div>
				<?php else: ?>
				<div class="small-img">
					<img src="<?php echo $settings['select_img']['url'];?>" alt="" />
				</div>
				<?php endif; ?>
			</div>
			<div class="icon-box-text-content">
				<div class="icon-box-title">
					<h2><?php echo $settings['title_text']; ?></h2>
				</div>
				<div class="icon-box-description">
					<p><?php echo $settings['description_text']; ?></p>
				</div>
			</div>
		</div>
		<?php }?>
		<?php
	}
}