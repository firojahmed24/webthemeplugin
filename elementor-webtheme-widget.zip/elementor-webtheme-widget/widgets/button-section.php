<?php
if(!defined('ABSPATH')) exit;
class ButtonSection extends \Elementor\Widget_Base{
	public function get_name(){
		return "buttonsection";
	}
	public function get_title(){
		return "Button Section";
	}
	public function get_icon(){
		return "eicon-button";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button Section', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'button_text',
				[
					'label' => __( 'Button Text', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Read More', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Read More', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'button_url',
				[
					'label' => __( 'Button Link', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'Enter Your Link Here', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'button_icon',
				[
					'label' => __( 'Button Icon', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::ICONS,
				]
			);
		$this->end_controls_section();

/* ==========    Button Section Css    ==========*/

		$this->start_controls_section(
			'option_section',
			[
				'label' => __( 'Button Options', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'select_option',
				[
					'label' => __( 'Choose Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
						'three' => __( 'Three', 'elementor-webtheme' ),
						'four' => __( 'Four', 'elementor-webtheme' ),
					],
					'default' => 'one',
				]
			);
			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .single-button' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'button_style',
			[
				'label' => esc_html__( 'Button css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'button_typography',
					'selector' => '{{WRAPPER}} .single-button .button-content a',
				]
			);

			$this->start_controls_tabs(
				'style_tabs'
			);

			$this->start_controls_tab(
				'style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'elementor-webtheme' ),
				]
			);

			$this->add_control(
				'text_color',
				[
					'label' => esc_html__( 'Button Text Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-button .button-content a' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'background',
					'label' => esc_html__( 'Button Background', 'elementor-webtheme' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .single-button .button-content a',
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'button_border',
					'label' => esc_html__( 'Button Border', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .single-button .button-content a',
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'button_border_radius',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Border Radius', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-button .button-content a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'box_shadow',
					'label' => esc_html__( 'Button Box Shadow', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .single-button .button-content a',
				]
			);
			$this->add_responsive_control(
				'button_padding',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Button Padding', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-button .button-content a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'button_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Button Margin', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-button .button-content a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'style_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'elementor-webtheme' ),
				]
			);

			$this->add_control(
				'text_hover_color',
				[
					'label' => esc_html__( 'Hover Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-button .button-content a:hover' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'hover_background',
					'label' => esc_html__( 'Hover BG', 'elementor-webtheme' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .single-button .button-content a:hover',
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'button_hover_border',
					'label' => esc_html__( 'Hover Border', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .single-button .button-content a:hover',
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'button_hover_border_radius',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Hover Border Radius', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-button .button-content a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'button_hover_padding',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Hover Button Padding', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-button .button-content a:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->end_controls_tab();
		$this->end_controls_tabs();
	$this->end_controls_section();
	$this->start_controls_section(
		'button-Icon_style',
		[
			'label' => esc_html__( 'Button Icon css', 'elementor-webtheme' ),
			'tab' => \Elementor\Controls_Manager::TAB_STYLE,
		]
	);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'button_icon_typography',
					'selector' => '{{WRAPPER}} .single-button .button-content a i',
				]
			);
	
			$this->start_controls_tabs(
				'style_icon_tabs'
			);

			$this->start_controls_tab(
				'style_icon_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'elementor-webtheme' ),
				]
			);

				$this->add_control(
					'icon_color',
					[
						'label' => esc_html__( 'Icon Color', 'elementor-webtheme' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .single-button .button-content a i' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Background::get_type(),
					[
						'name' => 'Icon_background',
						'label' => esc_html__( 'Icon Background', 'elementor-webtheme' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => '{{WRAPPER}} .single-button .button-content a i',
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'button_icon_border',
						'label' => esc_html__( 'Icon Border', 'elementor-webtheme' ),
						'selector' => '{{WRAPPER}} .single-button .button-content a i',
						'separator' => 'before',
					]
				);
				$this->add_responsive_control(
					'button_icon_border_radius',
					[
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'label' => esc_html__( 'Icon Border Radius', 'elementor-webtheme' ),
						'size_units' => [ 'px', 'em', '%' ],
						'selectors' => [
							'{{WRAPPER}} .single-button .button-content a i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'button_icon_padding',
					[
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'label' => esc_html__( 'Icon Padding', 'elementor-webtheme' ),
						'size_units' => [ 'px', 'em', '%' ],
						'selectors' => [
							'{{WRAPPER}} .single-button .button-content a i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'button_icon_margin',
					[
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'label' => esc_html__( 'Icon Margin', 'elementor-webtheme' ),
						'size_units' => [ 'px', 'em', '%' ],
						'selectors' => [
							'{{WRAPPER}} .single-button .button-content a i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->end_controls_tab();
	
				$this->start_controls_tab(
					'style_icon_hover_tab',
					[
						'label' => esc_html__( 'Hover', 'elementor-webtheme' ),
					]
				);
	
				$this->add_control(
					'icon_hover_color',
					[
						'label' => esc_html__( 'Hover Icon Color', 'elementor-webtheme' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .single-button .button-content a:hover i' => 'color: {{VALUE}}',
						],
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Background::get_type(),
					[
						'name' => 'hover_icon_background',
						'label' => esc_html__( 'Hover Icon BG', 'elementor-webtheme' ),
						'types' => [ 'classic', 'gradient' ],
						'selector' => '{{WRAPPER}} .single-button .button-content a:hover i',
					]
				);
				$this->add_group_control(
					\Elementor\Group_Control_Border::get_type(),
					[
						'name' => 'icon_hover_border',
						'label' => esc_html__( 'Hover Icon Border', 'elementor-webtheme' ),
						'selector' => '{{WRAPPER}} .single-button .button-content a:hover i',
						'separator' => 'before',
					]
				);
				$this->add_responsive_control(
					'icon_hover_border_radius',
					[
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'label' => esc_html__( 'Hover Icon Border Radius', 'elementor-webtheme' ),
						'size_units' => [ 'px', 'em', '%' ],
						'selectors' => [
							'{{WRAPPER}} .single-button .button-content a:hover i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'icon_hover_padding',
					[
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'label' => esc_html__( 'Hover Icon Padding', 'elementor-webtheme' ),
						'size_units' => [ 'px', 'em', '%' ],
						'selectors' => [
							'{{WRAPPER}} .single-button .button-content a:hover i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->add_responsive_control(
					'icon_hover_margin',
					[
						'type' => \Elementor\Controls_Manager::DIMENSIONS,
						'label' => esc_html__( 'Hover Icon Margin', 'elementor-webtheme' ),
						'size_units' => [ 'px', 'em', '%' ],
						'selectors' => [
							'{{WRAPPER}} .single-button .button-content a:hover i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
						],
					]
				);
				$this->end_controls_tab();
			$this->end_controls_tabs();
		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
			<?php if($settings['select_option']=='one'){ ?>
			<div class="single-button option1">
				<div class="button-content">
					<a href="<?php echo esc_url($settings['button_url']['url']); ?>">
						<?php echo $settings['button_text']; ?>
						<?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
					</a>
				</div>
			</div>
			<?php }elseif($settings['select_option']=='two'){ ?>
			<div class="single-button option2">
				<div class="button-content">
					<a href="<?php echo esc_url($settings['button_url']['url']); ?>">
						<?php echo $settings['button_text']; ?>
						<?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
					</a>
				</div>
			</div>
			<?php }elseif($settings['select_option']=='three'){ ?>
			<div class="single-button option3">
				<div class="button-content">
					<a href="<?php echo esc_url($settings['button_url']['url']); ?>">
						<?php echo $settings['button_text']; ?>
						<?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
					</a>
				</div>
			</div>
			<?php }elseif($settings['select_option']=='four'){ ?>
			<div class="single-button option1 option4">
				<div class="button-content">
					<a href="<?php echo esc_url($settings['button_url']['url']); ?>">
						<?php echo $settings['button_text']; ?>
						<?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
					</a>
				</div>
			</div>
		<?php } ?>
	<?php
	}
}