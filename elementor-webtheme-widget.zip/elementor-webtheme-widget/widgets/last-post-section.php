<?php
if(!defined('ABSPATH')) exit;
class lastPostSection extends \Elementor\Widget_Base{
	public function get_name(){
		return "last-post";
	}
	public function get_title(){
		return "Last Post";
	}
	public function get_icon(){
		return "eicon-table-of-contents";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
        /*---------  Last Post Section css style start here  --------*/
		$this->start_controls_section(
            'section_option',
            [
                'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'select_option',
                [
                    'label' => __( 'Select Your Option', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'options' => [
                        'one' => __( 'One', 'elementor-webtheme' ),
                        'two' => __( 'Two', 'elementor-webtheme' ),
                    ],
                    'default' => 'one',
                    
                ]
            );
		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => __( 'Title css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .single-last-post .last-post-title h1 a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .single-last-post .last-post-title h1 a',
				]
			);
			$this->add_responsive_control(
				'title_padding',
				[
					'label' => __( 'Title Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-last-post .last-post-title h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Title Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-last-post .last-post-title h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
        <?php if($settings['select_option']=='one'){ ?>
			<div class="last-post-section">
				<?php $the_query = new \WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 2 ) ); ?>
				<?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
					<div class="single-last-post">
						<div class="last-post-img">
							<?php the_post_thumbnail('last-blog-default'); ?>
						</div>
						<div class="last-post-content">
							<div class="last-post-title">
								<h1><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), 5,''); ?></a></h1>
							</div>
							<div class="last-post-time">
								<span><?php echo get_the_time(get_option('date_format')); ?></span>
							</div>
						</div>
					</div>
				<?php endwhile; ?>
			</div>
		<?php }elseif($settings['select_option']=='two'){ ?>
			<div class="last-post-section option2">
				<?php $the_query = new \WP_Query( array( 'post_type' => 'post', 'posts_per_page' => 2 ) ); ?>
				<?php while ($the_query->have_posts()) : $the_query->the_post(); ?>
					<div class="single-last-post">
						<div class="last-post-img">
							<?php the_post_thumbnail('last-blog-default'); ?>
						</div>
						<div class="last-post-content">
							<div class="last-post-title">
								<h1><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), 10,''); ?></a></h1>
							</div>
							<div class="last-post-time">
								<span><?php echo get_the_time(get_option('date_format')); ?></span>
							</div>
						</div>
					</div>
				<?php endwhile; ?>
			</div>
		<?php } ?>
		<?php
	}
}