<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if(!defined('ABSPATH')) exit;
class BrandSection extends Widget_Base{
	public function get_name(){
		return "brand";
	}
	public function get_title(){
		return "Brand Section";
	}
	public function get_icon(){
		return "eicon-star-o";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
		$this->start_controls_section(
			'brands_section',
			[
				'label' => esc_html__( 'Brand Images', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'brand_img',
			[
				'label' => esc_html__( 'Brand Images', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'brand_list',
			[
				'label' => esc_html__( 'Brand List', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'brand_name' => esc_html__( 'Brand img one', 'elementor-webtheme' ),
						'list_content' => esc_html__( 'Item content.', 'elementor-webtheme' ),
					],
					[
						'brand_name' => esc_html__( 'Brand img two', 'elementor-webtheme' ),
						'list_content' => esc_html__( 'Item content.', 'elementor-webtheme' ),
					],
				],
				'title_field' => '{{{ brand_name }}}',
			]
		);
		$this->end_controls_section();

/* ==========      Brant Tab Option      ========== */
		$this->start_controls_section(
			'style_section',
			[
				'label' => __( 'Brand Option', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'select_option',
				[
					'label' => __( 'Choose Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
					],
					'default' => 'one',
				]
			);
		$this->end_controls_section();
	}
	protected function render(){
		$settings = $this->get_settings_for_display();
		?>
			<?php if($settings['select_option']=='one'){ ?>
			<div class="brand-section option1">
				<div class="img-carousel-one owl-carousel">
					<?php foreach (  $settings['brand_list'] as $item ) { ?>
					<div class="brand-images">
						<img src="<?php echo $item['brand_img']['url']; ?>" alt="">
					</div>
					<?php } ?>
				</div>
			</div>
			<script>
				jQuery(document).ready(function($) {
					"use strict";	
                    $('.img-carousel-one').owlCarousel({
                    	loop: true,
                    	autoplay: true,
                    	autoplayTimeout: 4000,
                    	dots: false,
                    	nav: false,
                    	navText: ["<i class='fa fa-long-arrow-left'></i>", "<i class='fa fa-long-arrow-right''></i>"],
                    	responsive: {
                    		0: {
                    			items: 1
                    		},
                    		450: {
                    			items: 2
                    		},
                    		768: {
                    			items: 2
                    		},
                    		992: {
                    			items: 5
                    		},
                    		1500: {
                    			items: 5
                    		},
                    		1920: {
                    			items: 5
                    		}
                    	}
                    })
				});
			</script>
			<?php }elseif($settings['select_option']=='two'){ ?>
			<div class="brand-section option2">
				<div class="img-carousel-two owl-carousel">
					<?php foreach (  $settings['brand_list'] as $item ) { ?>
					<div class="brand-images">
						<img src="<?php echo $item['brand_img']['url']; ?>" alt="">
					</div>
					<?php } ?>
				</div>
			</div>
			<script>
				jQuery(document).ready(function($) {
					"use strict";
                    $('.img-carousel-two').owlCarousel({
                    	loop: true,
                    	autoplay: true,
                    	autoplayTimeout: 4000,
                    	dots: false,
                    	nav: false,
                    	navText: ["<i class='fa fa-long-arrow-left'></i>", "<i class='fa fa-long-arrow-right''></i>"],
                    	responsive: {
                    		0: {
                    			items: 2
                    		},
                    		768: {
                    			items: 3
                    		},
                    		992: {
                    			items: 4
                    		},
                    		1500: {
                    			items: 5
                    		},
                    		1920: {
                    			items: 5
                    		}
                    	}
                    })
				});
			</script>
			<?php } ?>
		<?php
	}
}