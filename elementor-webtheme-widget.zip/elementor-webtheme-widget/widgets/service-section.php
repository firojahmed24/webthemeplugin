<?php
if(!defined('ABSPATH')) exit;
class ServiceSection extends \Elementor\Widget_Base{
	public function get_name(){
		return "service_section";
	}
	public function get_title(){
		return "Service Section";
	}
	public function get_icon(){
		return "eicon-info-box";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
		$this->start_controls_section(
			'icon_section',
			[
				'label' => __( 'Icon or Image', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'icons_type',
				[
				    'label' => esc_html__('Icon Type','elementor-webtheme'),
				    'type' => \Elementor\Controls_Manager::CHOOSE,
				    'options' =>[
					  'img' =>[
						'title' =>esc_html__('Icon Image','elementor-webtheme'),
						'icon' =>'eicon-image',
					  ],
					  'icon' =>[
						'title' =>esc_html__('Icon','elementor-webtheme'),
						'icon' =>'fa fa-info',
					  ]
				    ],
				    'default' => 'icon',
				]
			 );
			 $this->add_control(
				'select_icon',
				[
					'label' => esc_html__( 'Icon', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'condition'=>[
						'icons_type'=> 'icon',
					],
					'label_block' => true,
				]
			);
			$this->add_control(
				'icon_img',
				[
				    'label' => esc_html__('Icon Image','elementor-webtheme'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'image_section',
			[
				'label' => __( 'Service Image', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'single_image',
				[
				    'label' => esc_html__('Service Image','elementor-webtheme'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'service_section',
			[
				'label' => __( 'Text Content', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'service_number',
				[
					'label' => __( 'Service Number', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Service Number', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( '01', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'title_one',
				[
					'label' => __( 'Title One', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter Title One', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Service Title One', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'title_two',
				[
					'label' => __( 'Title Two', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter Title Two', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Service Title Two', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'description',
				[
					'label' => __( 'Description', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter Service Description', 'elementor-webtheme' ),
					'default' => __( 'This is service description. You can Change description.', 'elementor-webtheme' ),
				]
			);
		$this->end_controls_section();
		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Service Button', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'button_text',
				[
					'label' => __( 'Button Text', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter button text', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Read More', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'link',
				[
					'label' => __( 'Button Link', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::URL,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'https://your-link.com', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'show_button',
				[
					'label' => __( 'Show Button', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'elementor-webtheme' ),
					'label_off' => __( 'Hide', 'elementor-webtheme' ),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);
			$this->add_control(
				'button_icon',
				[
					'label' => __( 'Button Icon', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'default' => [
						'value' => 'fa fa-angle-right',
						'library' => 'solid',
					],
				]
			);
		$this->end_controls_section();

        /*---------  Service Section css style start here  --------*/

        $this->start_controls_section(
            'section_option',
            [
                'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'select_option',
                [
                    'label' => __( 'Select Your Option', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'options' => [
                        'one' => __( 'One', 'elementor-webtheme' ),
                        'two' => __( 'Two', 'elementor-webtheme' ),
                    ],
                    'default' => 'one',
                    
                ]
            );
			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service-section' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'single_box_section_style',
			[
				'label' => __( 'Service Box css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'single_box_bg_color',
			[
				'label' => __( 'Single Box BG Color', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .service-section' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'hover_single_bg_color',
			[
				'label' => __( 'Hover Box BG Color', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .service-section:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'single_border',
				'label' => __( 'Single Box Border', 'elementor-webtheme' ),
				'selector' => '{{WRAPPER}} .service-section',
			]
		);
		$this->add_responsive_control(
			'single_border_radius',
			[
				'label' => __( 'Box Border Radius', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .service-section' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'hover_single_border',
				'label' => __( 'Hover Box Border', 'elementor-webtheme' ),
				'selector' => '{{WRAPPER}} .service-section:hover',
			]
		);
		$this->add_responsive_control(
			'hover_box_border_radius',
			[
				'label' => __( 'Hover Box Border Radius', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .service-section:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'single_box_padding',
			[
				'label' => __( 'Single Box Padding', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .service-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'single_box_margin',
			[
				'label' => __( 'Single Box Margin', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .service-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
		$this->end_controls_section();
		
		$this->start_controls_section(
			'icon_section_style',
			[
				'label' => __( 'Icon css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		
		$this->start_controls_tabs(
			'style_tabs'
		);
		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => __( 'Normal', 'elementor-webtheme' ),
			]
		);
			$this->add_control(
				'icon_color',
				[
					'label' => __( 'Icon Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-section .service-icon-img i' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'icon_background_color',
				[
					'label' => __( 'Icon BG Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-section .service-icon-img i' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'icon_border',
					'label' => __( 'Icon Border', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .service-section .service-icon-img i',
				]
			);
			$this->add_responsive_control(
				'icon_border_radius',
				[
					'label' => __( 'Icon Border Radius', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-icon-img i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => __( 'Hover', 'elementor-webtheme' ),
			]
		);
			$this->add_control(
				'hover_icon_color',
				[
					'label' => __( 'Icon Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-section:hover .service-icon-img i' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'hover_background_color',
				[
					'label' => __( 'Icon BG Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-section:hover .service-icon-img i' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'hover_icon_border',
					'label' => __( 'Icon Border', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .service-section:hover .service-icon-img i',
				]
			);
			$this->add_responsive_control(
				'hover_icon_border_radius',
				[
					'label' => __( 'Icon Border Radius', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section:hover .service-icon-img i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		
			$this->add_responsive_control(
				'icon_align',
				[
					'label' => __( 'Icon Alignment', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-icon-img i' => 'text-align: {{VALUE}};',
					],
				]
			);
			$this->add_responsive_control(
				'icon_margin',
				[
					'label' => __( 'Icon Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-icon-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'height',
				[
					'label' => __( 'Icon Height', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-icon-img i' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'width',
				[
					'label' => __( 'Icon Width', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-icon-img i' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'icon_typography',
					'selector' => '{{WRAPPER}} .service-section .service-icon-img i',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'number_section_style',
			[
				'label' => __( 'Number css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'number_color',
				[
					'label' => __( 'Number Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-section .service-number h5' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'number_typography',
					'selector' => '{{WRAPPER}} .service-section .service-number h5',
				]
			);
			$this->add_responsive_control(
				'number_margin',
				[
					'label' => __( 'Number Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-number h5' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();


		$this->start_controls_section(
			'title_section_style',
			[
				'label' => __( 'Title One css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title One Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-section .service-title h1' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .service-section .service-title h1',
				]
			);
			$this->add_responsive_control(
				'title_padding',
				[
					'label' => __( 'Title Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-title h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Title One Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-title h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);

		$this->end_controls_section();
		$this->start_controls_section(
			'title_two_section_style',
			[
				'label' => __( 'Title Two css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'title_two_color',
				[
					'label' => __( 'Title Two Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-section .service-title h2' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_two_typography',
					'selector' => '{{WRAPPER}} .service-section .service-title h2',
				]
			);
			$this->add_responsive_control(
				'title_two_padding',
				[
					'label' => __( 'Title Two Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-title h2' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'title_two_margin',
				[
					'label' => __( 'Title Two Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'description_section_style',
			[
				'label' => __( 'Description css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'description_color',
				[
					'label' => __( 'Description Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-section .service-description p' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'selector' => '{{WRAPPER}} .service-section .service-description p',
				]
			);
			$this->add_responsive_control(
				'description_padding',
				[
					'label' => __( 'Desc Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-description p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_responsive_control(
				'description_margin',
				[
					'label' => __( 'Desc Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-description p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'button_section_style',
			[
				'label' => __( 'Button css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->start_controls_tabs(
				'button_style_tabs'
			);
				$this->start_controls_tab(
					'button_style_normal_tab',
					[
						'label' => __( 'Normal', 'elementor-webtheme' ),
					]
				);
				
					$this->add_control(
						'button_text_color',
						[
							'label' => __( 'Button Text Color', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .service-section .service-button a' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_control(
						'button_background_color',
						[
							'label' => __( 'Button BG Color', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .service-section .service-button a' => 'background-color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'button_border',
							'label' => __( 'Button Border', 'elementor-webtheme' ),
							'selector' => '{{WRAPPER}} .service-section .service-button a',
						]
					);
					$this->add_responsive_control(
						'button_border_radius',
						[
							'label' => __( 'Button Border Radius', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .service-section .service-button a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_control(
						'button_icon_color',
						[
							'label' => __( 'Button Icon Color', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .service-section .service-button a i' => 'color: {{VALUE}};',
							],
						]
					);
				$this->end_controls_tab();
				
				$this->start_controls_tab(
					'button_style_hover_tab',
					[
						'label' => __( 'Hover', 'elementor-webtheme' ),
					]
				);
					$this->add_control(
						'hover_button_text_color',
						[
							'label' => __( 'Button Text Color', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .service-section .service-button a:hover' => 'color: {{VALUE}};',
							],
						]
					);
					$this->add_control(
						'hover_button_background_color',
						[
							'label' => __( 'Button BG Color', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .service-section .service-button a:hover' => 'background-color: {{VALUE}};',
							],
						]
					);
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'hover_button_border',
							'label' => __( 'Button Border', 'elementor-webtheme' ),
							'selector' => '{{WRAPPER}} .service-section .service-button a:hover',
						]
					);
					$this->add_responsive_control(
						'hover_button_border_radius',
						[
							'label' => __( 'Button Border Radius', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .service-section .service-button a:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
				$this->end_controls_tab();
				
			$this->end_controls_tabs();

			$this->add_responsive_control(
				'button_padding',
				[
					'label' => __( 'Button Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'button_margin',
				[
					'label' => __( 'Button Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-button a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_control(
				'button_height',
				[
					'label' => __( 'Button Height', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-button a' => 'height: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'button_width',
				[
					'label' => __( 'Button Width', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SLIDER,
					'size_units' => [ 'px', '%' ],
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 1000,
							'step' => 5,
						],
						'%' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service-section .service-button a' => 'width: {{SIZE}}{{UNIT}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'button_typography',
					'selector' => '{{WRAPPER}} .service-section .service-button a',
				]
			);

		$this->end_controls_section();

	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_render_attribute( 'title_one', 'class', 'service-box-title' );
		$this->add_render_attribute( 'description', 'class', 'service-box-desc' );

		$has_button_icon = ! empty( $settings['button_icon'] );
		if ( $has_button_icon ) {
			$this->add_render_attribute( 'j', 'class', $settings['button_icon'] );
		}
		?>
		<?php if($settings['select_option']=='one'){ ?>
			<div class="service-section option1">
				<div class="service-number">
					<h5><?php echo $settings['service_number'];?></h5>
				</div>
				<div class="service-single-image">
                    <img src="<?php echo $settings['single_image']['url']; ?>" alt="">
                </div>
				<div class="service-text-content">
					<div class="service-icon-img">
						<?php if($settings['icons_type'] == 'icon' ){ ?>
							<?php \Elementor\Icons_Manager::render_icon( $settings['select_icon'], [ 'aria-hidden' => 'true' ] ); ?>
						<?php }elseif($settings['icons_type'] == 'img'){ ?>
							<img src="<?php echo $settings['icon_img']['url']; ?>" alt="<?php esc_attr_e('elementor-webtheme', 'elementor-webtheme'); ?>">
						<?php } ?>
					</div>
					<div class="service-title">
						<?php if($settings['title_one']) : ?>
							<h1><?php echo $settings['title_one']; ?></h1>
							<?php endif; ?>
						<?php if($settings['title_two']) : ?>
							<h2><?php echo $settings['title_two']; ?></h2>
						<?php endif; ?>
					</div>
					<div class="service-description">
						<?php if($settings['description']) : ?>
							<p><?php echo $settings['description']; ?></p>
						<?php endif; ?>
					</div>
					<?php if( 'yes'===$settings['show_button'] ){ ?>
						<div class="service-button">
							<a href="<?php echo esc_url($settings['link']['url']); ?>">
								<?php echo $settings['button_text']; ?>
								<?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							</a>
						</div>
					<?php } ?>
				</div>
				
			</div>

		<?php }elseif($settings['select_option']=='two'){ ?>

			<div class="service-section option2">
				
				<?php if($settings['service_number']) : ?>
					<div class="service-number">
					<h5><?php echo $settings['service_number'];?></h5>
				</div>
				<?php endif; ?>
				<div class="service-single-image">
                    <img src="<?php echo $settings['single_image']['url']; ?>" alt="">
                </div>
				<div class="service-text-content">
					<div class="service-icon-img">
						<?php if($settings['icons_type'] == 'icon' ){ ?>
							<?php \Elementor\Icons_Manager::render_icon( $settings['select_icon'], [ 'aria-hidden' => 'true' ] ); ?>
						<?php }elseif($settings['icons_type'] == 'img'){ ?>
							<img src="<?php echo $settings['icon_img']['url']; ?>" alt="<?php esc_attr_e('elementor-webtheme', 'elementor-webtheme'); ?>">
						<?php } ?>
					</div>
					<div class="service-title">
						<?php if($settings['title_one']) : ?>
							<h1><?php echo $settings['title_one']; ?></h1>
						<?php endif; ?>
						<?php if($settings['title_two']) : ?>
							<h2><?php echo $settings['title_two']; ?></h2>
						<?php endif; ?>
					</div>
					<div class="service-description">
						<?php if($settings['description']) : ?>
							<p><?php echo $settings['description']; ?></p>
						<?php endif; ?>
					</div>
					<?php if( 'yes'===$settings['show_button'] ){ ?>
						<div class="service-button">
							<a href="<?php echo esc_url($settings['link']['url']); ?>">
								<?php echo $settings['button_text']; ?>
								<?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							</a>
						</div>
					<?php } ?>
				</div>
			</div>
		<?php }
	}
}