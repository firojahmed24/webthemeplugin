<?php
class ShortcodeMail extends \Elementor\Widget_Base {
    public function get_name() {
		return 'shortcode_mail';
	}
	public function get_title() {
		return esc_html__( 'Shortcode', 'elementor-webtheme' );
	}
	public function get_icon() {
		return 'eicon-shortcode';
	}
	public function get_custom_help_url() {
		return 'https://go.elementor.com/widget-name';
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	public function get_keywords() {
		return [ 'shortcode' ];
	}
	protected function register_controls() {
		$this->start_controls_section(
			'section_shortcode',
			[
				'label' => esc_html__( 'Shortcode', 'elementor' ),
			]
		);

		$this->add_control(
			'shortcode',
			[
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'label' => esc_html__( 'shortcode', 'elementor-webtheme' ),
				'placeholder' => esc_html__( 'Enter your shortcode', 'elementor-webtheme' ),
				'description' => 'Control shortcode',
				'label_block' => true ,
				'show_label' => true ,
				'default' => '',
				'rows' => 3,
				'separator' => 'before',
				'dynamic' => [
					'active' => true,
				],
				'ai' => [
					'active' => false,
				],
				'placeholder' => '[gallery id="123" size="medium"]',
			]
		);
		$this->end_controls_section();
	}
	protected function render() {
		$shortcode = $this->get_settings_for_display( 'shortcode' );
		if ( empty( $shortcode ) ) {
			return;
		}
		$shortcode = do_shortcode( shortcode_unautop( $shortcode ) );
		?>
		<div class="shortcode-mail">
			<?php echo $shortcode; ?>
		</div>
		<?php
	}
}