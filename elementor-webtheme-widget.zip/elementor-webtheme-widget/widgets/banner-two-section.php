<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
if(!defined('ABSPATH')) exit;
class BannerTwoSection extends Widget_Base{
	public function get_name(){
		return "bannertwosection";
	}
	public function get_title(){
		return "Banner 02 Section";
	}
	public function get_icon(){
		return "eicon-info-box";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Banner Text Content', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
            $this->add_group_control(
                \Elementor\Group_Control_Background::get_type(),
                [
                    'name' => 'background',
                    'label' => __( 'banner Background', 'elementor-webtheme' ),
                    'types' => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .banner-section',
                ]
            );
            $this->add_control(
                'banner_subtitle',
                [
                    'label' => __( 'Subtitle', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Banner Subtitle', 'elementor-webtheme' ),
                    'placeholder' => __( 'Enter Subtitle', 'elementor-webtheme' ),
                    'separator' => 'before',
                    'label_block' => true,
                ]
            );
            $this->add_control(
                'banner_title1',
                [
                    'label' => __( 'Title One', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Banner Title One', 'elementor-webtheme' ),
                    'placeholder' => __( 'Enter your title', 'elementor-webtheme' ),
                    'label_block' => true,
                ]
            );
            $this->add_control(
                'banner_title2',
                [
                    'label' => __( 'Banner Title Two', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Banner Title Two', 'elementor-webtheme' ),
                    'placeholder' => __( 'Enter your title', 'elementor-webtheme' ),
                    'label_block' => true,
                ]
            );
            $this->add_control(
                'banner_description',
                [
                    'label' => __( 'Banner Description', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                    'default' => __( 'The introduction of new sports and more urban and visually spectacular venues are necessary to attract younger audiences to secure the Olympic Games', 'elementor-webtheme' ),
                    'placeholder' => __( 'Enter your Description', 'elementor-webtheme' ),
                ]
            );
            $this->add_control(
                'single_image',
                [
                    'label' => __( 'Select Image', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    
                ]
            );
        $this->end_controls_section();
        $this->start_controls_section(
            'button_section',
            [
                'label' => __( 'Banner Button', 'elementor-webtheme' ),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'show_button',
            [
                'label' => __( 'Show or Hide Button', 'elementor-webtheme' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __( 'Show', 'elementor-webtheme' ),
                'label_off' => __( 'Hide', 'elementor-webtheme' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );
            $this->add_control(
                'button_text',
                [
                    'label' => __( 'Button Text', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Know More', 'elementor-webtheme' ),
                    'placeholder' => __( ' Enter text', 'elementor-webtheme' ),
                    'label_block' => true,
                ]
            );
			$this->add_control(
				'button_link',
				[
					'label' => __( 'Banner Button Link', 'elementor-webtheme' ),
					'type' => Controls_Manager::URL,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'https://your-link.com', 'elementor-webtheme' ),
				]
			);
            $this->add_control(
				'button_icon',
				[
					'label' => __( 'Button Icon', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::ICONS,
				]
			);
            $this->add_control(
				'show_button2',
				[
					'label' => __( 'Show or Hide Button2', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'elementor-webtheme' ),
					'label_off' => __( 'Hide', 'elementor-webtheme' ),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);
            $this->add_control(
                'button_text2',
                [
                    'label' => __( 'Button2 Text', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => __( 'Know More', 'elementor-webtheme' ),
                    'placeholder' => __( ' Enter text', 'elementor-webtheme' ),
                    'label_block' => true,
                ]
            );
			$this->add_control(
				'button_link2',
				[
					'label' => __( 'Banner Button2 Link', 'elementor-webtheme' ),
					'type' => Controls_Manager::URL,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'https://your-link.com', 'elementor-webtheme' ),
				]
			);
            $this->add_control(
				'button_icon2',
				[
					'label' => __( 'Button2 Icon', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::ICONS,
				]
			);
		$this->end_controls_section();

		
        
/*==========   Banner section style start here  ==========*/

        $this->start_controls_section(
            'section_option',
            [
                'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'select_option',
                [
                    'label' => __( 'Select Your Option', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'options' => [
                        'one' => __( 'One', 'elementor-webtheme' ),
                        'two' => __( 'Two', 'elementor-webtheme' ),
                    ],
                    'default' => 'one',
                    
                ]
            );
            $this->add_responsive_control(
                'text_align',
                [
                    'label' => __( 'Alignment', 'elementor-webtheme' ),
                    'type' => Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'elementor-webtheme' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'elementor-webtheme' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'elementor-webtheme' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                        'justify' => [
                            'title' => __( 'Justified', 'elementor-webtheme' ),
                            'icon' => 'eicon-text-align-justify',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .banner-section' => 'text-align: {{VALUE}};',
                    ],
                ]
            );
            $this->add_responsive_control(
                'section_height',
                [
                    'label' => __( 'Height', 'elementor-webtheme' ),
                    'type' => Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1500,
                            'step' => 1,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .banner-section' => 'min-height: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section(
            'banner-text_style',
            [
                'label' => esc_html__( 'Banner Text css', 'elementor-webtheme' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        /*  subtitle css start here  */
        $this->add_control(
            'subtitle_heading',
            [
                'label' => __( 'SubTitle', 'elementor-webtheme' ),
                'type' => \Elementor\Controls_Manager::HEADING,
            ]
        );
        $this->add_control(
            'subtitle_color',
            [
                'label' => __( 'SubTitle Color', 'elementor-webtheme' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .banner-section .banner-subtitle h4' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'label' => __( 'Subtitle Typography', 'elementor-webtheme' ),
                'selector' => '{{WRAPPER}} .banner-section .banner-subtitle h4',
            ]
        );
        $this->add_responsive_control(
            'title_margin',
            [
                'label' => __( 'Subtitle Margin', 'elementor-webtheme' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .banner-section .banner-subtitle h4' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );/*  subtitle css end here  */

        /*  Title css start here  */
            $this->add_control(
                'title_heading',
                [
                    'label' => __( 'Banner Title One', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                ]
            );
            $this->add_control(
                'title_color',
                [
                    'label' => __( 'Title One Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .banner-section .banner-title-one h2' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'title_typography',
                    'label' => __( 'Title One Typography', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .banner-section .banner-title-one h2',
                ]
            );
            $this->add_responsive_control(
                'title_margin',
                [
                    'label' => __( 'Ttitle One Margin', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .banner-section .banner-title-one h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_control(
                'title_heading_two',
                [
                    'label' => __( 'Banner Title Two', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                ]
            );
            $this->add_control(
                'title_two_color',
                [
                    'label' => __( 'Title Two Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .banner-section .banner-title-two h3' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'title_two_typography',
                    'label' => __( 'Title Two Typography', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .banner-section .banner-title-two h3',
                ]
            );
            $this->add_responsive_control(
                'title_two_margin',
                [
                    'label' => __( 'Title Two Margin', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .banner-section .banner-title-two h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            /*  Title css end here  */

            /*  Description css start here  */
            $this->add_control(
                'description_heading',
                [
                    'label' => __( 'Banner Description', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'description_color',
                [
                    'label' => __( 'Description Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .banner-section .banner-description p' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'description_typography',
                    'label' => __( 'Descriptiopn Typography', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .banner-section .banner-description p',
                ]
            );
            $this->add_responsive_control(
                'description_margin',
                [
                    'label' => __( 'Description Margin', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .banner-section .banner-description p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            ); /*  Description css end here  */
        $this->end_controls_section();

        /*  Button css start here  */
        $this->start_controls_section(
            'button_style',
            [
                'label' => esc_html__( 'Banner Button', 'elementor-webtheme' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'style_tabs'
        );
            $this->start_controls_tab(
                'button_normal_tab',
                [
                    'label' => __( 'Normal', 'elementor-webtheme' ),
                ]
            );
                $this->add_control(
                    'button_color',
                    [
                        'label' => __( 'Button Color', 'elementor-webtheme' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .banner-section .banner-button a' => 'color: {{VALUE}}',
                        ],
                    ]
                );
                $this->add_control(
                    'button_BG_color',
                    [
                        'label' => __( 'Button BG Color', 'elementor-webtheme' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .banner-section .banner-button a' => 'background: {{VALUE}}',
                        ],
                    ]
                );
            $this->end_controls_tab();
            $this->start_controls_tab(
                'button_hover_tab',
                [
                    'label' => __( 'Button Hover', 'elementor-webtheme' ),
                ]
            );
                $this->add_control(
                    'button_hover_color',
                    [
                        'label' => __( 'Hover Color', 'elementor-webtheme' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .banner-section .banner-button a:hover' => 'color: {{VALUE}}',
                        ],
                    ]
                );
                $this->add_control(
                    'button_bg_hover_color',
                    [
                        'label' => __( 'Hover BG Color', 'elementor-webtheme' ),
                        'type' => \Elementor\Controls_Manager::COLOR,
                        'selectors' => [
                            '{{WRAPPER}} .banner-section .banner-button a:hover' => 'background: {{VALUE}}',
                        ],
                    ]
                );
            $this->end_controls_tab();
        $this->end_controls_tabs();
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'button_typography',
                    'label' => __( 'Button Typography', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .banner-section .banner-button a',
                ]
            );
            $this->add_responsive_control(
                'button_margin',
                [
                    'label' => __( 'Button Margin', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .banner-section .banner-button' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_responsive_control(
                'button_padding',
                [
                    'label' => __( 'Batton Padding', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .banner-section .banner-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );/*  button css end here  */
        $this->end_controls_section();
	}

    /*  Banner section start here  */
	protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <?php if($settings['select_option']=='one'){ ?>
        <div class="banner-section banner-two">

            <div id="particles-banner-animate"></div>
            
            <div class="container">
                <div class="row d-flex align-items-center">
                    <div class="col-lg-12 col-md-12">
                        <div class="banner-content banner-02">
                            <div class="banner-subtitle">
                                <h4><?php echo $settings['banner_subtitle']; ?></h4>
                            </div>
                            <div class="banner-title-one">
                                <h2><?php echo $settings['banner_title1']; ?></h2>
                            </div>
                            <div class="banner-title-two">
                                <h3><?php echo $settings['banner_title2']; ?></h3>
                            </div>
                            <?php if( !empty($settings['banner_description']) ){ ?>
                            <div class="banner-description">
                                <p><?php echo $settings['banner_description']; ?></p>
                            </div>
                            <?php } ?>     
                            <?php if( $settings['show_button'] == 'yes' ){ ?>
                            <div class="banner-button">
                                <a href="<?php echo esc_url($settings['button_link']['url']); ?>"><?php echo $settings['button_text']; ?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            </a>
                            </div>
                            <?php } ?>
                            <?php if( $settings['show_button2'] == 'yes' ){ ?>
                            <div class="banner-button two">
                                <a href="<?php echo esc_url($settings['button_link2']['url']); ?>"><?php echo $settings['button_text2']; ?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['button_icon2'], [ 'aria-hidden' => 'true' ] ); ?>
                            </a>
                            </div>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div><!-- .conteiner -->
        </div>
        <?php }elseif($settings['select_option']=='two'){ ?>
            <div class="banner-section option2">

                <div class="container-fluid">
                        <div class="banner-content">
                            <div class="banner-subtitle">
                                <h4><?php echo $settings['banner_subtitle']; ?></h4>
                            </div>
                            <div class="banner-title-one">
                                <h2><?php echo $settings['banner_title1']; ?></h2>
                            </div>
                            <div class="banner-title-two">
                                <h3><?php echo $settings['banner_title2']; ?></h3>
                            </div>
                            <?php if( !empty($settings['banner_description']) ){ ?>
                            <div class="banner-description">
                                <p><?php echo $settings['banner_description']; ?></p>
                            </div>
                            <?php } ?>     
                            <?php if( $settings['show_button'] == 'yes' ){ ?>
                            <div class="banner-button">
                                <a href="<?php echo esc_url($settings['button_link']['url']); ?>"><?php echo $settings['button_text']; ?><i class="flaticon-right-arrow"></i></a>
                            </div>
                            <?php } ?>
                        </div>
                        <div class="single-image">
                            <img src="<?php echo esc_url($settings['single_image']['url']); ?>" alt="">
                        </div>
                    </div><!-- .banner-main -->
                </div>

            <?php } ?>
        <?php
	}
}