<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if(!defined('ABSPATH')) exit;
class VideoBoxSection extends Widget_Base{
	public function get_name(){
		return "videobox";
	}
	public function get_title(){
		return "Video Box";
	}
	public function get_icon(){
		return "eicon-icon-box";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){

        $this->start_controls_section(
            'settings_section',
            [
                'label' => esc_html__('General Settings', 'elementor-webtheme'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'image', [
                'label' => esc_html__('Video BG Image', 'elementor-webtheme'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => false,
                'description' => esc_html__('Enter Video BG img', 'elementor-webtheme'),
            ]
        );
		$this->add_control(
			'button_text',
			[
				'label' => esc_html__( 'Button Text', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Play', 'elementor-webtheme' ),
				'placeholder' => esc_html__( 'Enter text', 'elementor-webtheme' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'button_icon',
			[
				'label' => __( 'Button Icon', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::ICONS,
			]
		);
        $this->add_control(
            'video_link',
            [
                'label' => esc_html__('Video Link', 'elementor-webtheme'),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('https://www.youtube.com/watch?v=Z4F3AXvrLKo', 'elementor-webtheme'),
            ]
        );
        $this->end_controls_section();
		$this->start_controls_section(
            'animation_section',
            [
                'label' => esc_html__('Circle Content', 'elementor-webtheme'),
                'tab' => Controls_Manager::TAB_CONTENT,
            ]
        );
        $this->add_control(
            'title', [
                'label' => esc_html__('title', 'elementor-webtheme'),
                'type' => Controls_Manager::TEXTAREA,
                'description' => esc_html__('Enter Title.', 'elementor-webtheme'),
                'default' => esc_html__('Play video', 'elementor-webtheme')
            ]
        );
        $this->add_control(
            'animation_image',
            [
                'label' => esc_html__('Animation Image', 'elementor-webtheme'),
                'type' => Controls_Manager::MEDIA,
                'show_label' => true,
                'description' => esc_html__('Animation Image', 'elementor-webtheme'),
                
            ]
        );
        $this->end_controls_section();
	}

	protected function render() {

		$settings = $this->get_settings_for_display();


		?>
			<div class="video-box-content">
				<div class="video-button">
					<?php if($settings['image']) : ?>
						<img src="<?php echo $settings['image']['url']; ?>" alt="" class="cover-img">
					<?php endif; ?>
					<?php if($settings['video_link']) : ?>
						<a href="<?php echo $settings['video_link']; ?>" class="video-popup-button">
							<?php if($settings['video_link']) : ?>
								<?php echo $settings['button_text']; ?>
							<?php endif; ?>
							<?php if($settings['video_link']) : ?>
								<?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
							<?php endif; ?>
						</a>
					<?php endif; ?>
				</div>
			</div>
			<div class="circle-animation">
				<a data-aos="flip-left" class="circle-animate">
					<div class="text-inner">
						<svg xmlns="http://www.w3.org/2000/svg" width="250" height="250" viewBox="0 0 250 250">
							<path d="M.25,125.25a125,125,0,1,1,125,125,125,125,0,0,1-125-125" id="e-path-35ee1b2"></path>
							<text>
								<textPath id="e-text-path-35ee1b2" href="#e-path-35ee1b2" startOffset="0%">
									<?php if($settings['title']) : ?>
										<?php echo $settings['title']; ?>
									<?php endif; ?>
								</textPath>
							</text>
						</svg>
					</div>
				</a>
			</div>
		<?php
	}
}