<?php
if(!defined('ABSPATH')) exit;
class HeadingTitle extends \Elementor\Widget_Base {
	public function get_name() {
		return 'headingtitle';
	}
	public function get_title() {
		return esc_html__( 'Heading Title', 'elementor-webtheme' );
	}
	public function get_icon() {
		return 'eicon-typography-1';
	}
	public function get_categories() {
		return [ 'elementor-webtheme-category' ];
	}
	public function get_keywords() {
		return [ 'heading', 'title' ];
	}
	protected function register_controls() {
		$this->start_controls_section(
			'heading_text',
			[
				'label' => esc_html__( 'Heading Title', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'heading_title',
				[
					'label' => esc_html__( 'Heading Title', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'default' => esc_html__( 'This is Heading Title', 'elementor-webtheme' ),
					'placeholder' => esc_html__( 'Enter Heading Title', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'html_tag',
				[
					'label' => esc_html__( 'HTML Tag', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'default' => 'h1',
					'options' => [
						'h1'  => esc_html__( 'H1', 'elementor-webtheme' ),
						'h2' => esc_html__( 'H2', 'elementor-webtheme' ),
						'h3' => esc_html__( 'H3', 'elementor-webtheme' ),
						'h4' => esc_html__( 'H4', 'elementor-webtheme' ),
						'h5' => esc_html__( 'H5', 'elementor-webtheme' ),
						'h6' => esc_html__( 'H6', 'elementor-webtheme' ),
						'p' => esc_html__( 'p', 'elementor-webtheme' ),
						'span' => esc_html__( 'span', 'elementor-webtheme' ),
					],
				]
			);
		$this->end_controls_section();

/*==========     Main title css start here            ==========*/

		$this->start_controls_section(
			'section_option',
			[
				'label' => __( 'Choose Option', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
				'select_option',
				[
					'label' => __( 'Select Your Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
					],
					'default' => 'one',
					
				]
			);

			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .single-heading' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title CSS', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'title_color',
				[
					'label' => esc_html__( 'Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .single-heading .heading-title' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .single-heading .heading-title',
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Margin', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-heading .heading-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<?php if($settings['select_option']=='one'){?>
			<div class="single-heading">
				<<?php echo $settings['html_tag']; ?> class="heading-title"><?php echo $settings['heading_title']; ?></<?php echo $settings['html_tag']; ?>>
			</div>
		<?php }if($settings['select_option']=='two'){?>
			<div class="single-heading option2">
				<<?php echo $settings['html_tag']; ?> class="heading-title"><?php echo $settings['heading_title']; ?></<?php echo $settings['html_tag']; ?>>
			</div>
		<?php }?>
		<?php
	}
}