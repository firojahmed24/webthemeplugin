<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
if(!defined('ABSPATH')) exit;
class CircleProgress extends Widget_Base{
	public function get_name(){
		return "circleprogress";
	}
	public function get_title(){
		return "Circle Progress";
	}
	public function get_icon(){
		return "eicon-info-box";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function _register_controls(){
			$this->start_controls_section(
				'content_section',
				[
					'label' => __( 'Circle Progress', 'elementor-webtheme' ),
					'tab' => Controls_Manager::TAB_CONTENT,
				]
			);
		
    		$this->add_control(
    			'title',
    			[
    				'label' => __( 'Progress Title', 'elementor-webtheme' ),
    				'type' => Controls_Manager::TEXT,
    			]
    		);
    		$this->add_control(
    			'progress',
    			[
    				'label' => __( 'Progress Number', 'elementor-webtheme' ),
    				'type' => Controls_Manager::SLIDER,
    				'size_units' => [ '%' ],
    				'range' => [
    					'%' => [
    						'min' => 0,
    						'max' => 100,
    					],
    				],
    				'default' => [
    					'unit' => '%',
    					'size' => 70,
    				],
    			]
    		);
		
		$this->end_controls_section();
		
		$this->start_controls_section(
			'section_css',
			[
				'label' => __( 'Progress CSS', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'progress_color',
			[
				'label' => __( 'Progress Color', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .circle-progress-content .circle-progress-graph' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .circle-progress-content .circle-progress-value' => 'color: {{VALUE}}',
				],
			]
		);
		$this->end_controls_section();

			$this->start_controls_section(
				'title_section_ccs',
				[
					'label' => __( 'Title CSS', 'elementor-webtheme' ),
					'tab' => \Elementor\Controls_Manager::TAB_STYLE,
				]
			);
			$this->add_control(
				'title_color',
				[
					'label' => __( 'Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .single-circle-progress .progress-title h2' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .single-circle-progress .progress-title h2',
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .single-circle-progress .progress-title h2' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
	}
/*================   Circle Progress    ===============*/
	protected function render() {
	    $settings = $this->get_settings_for_display();
	    ?>
		<div class="single-circle-progress align-items-center d-flex">
			<div class="circle-progress-content" data-percentage="<?php echo $settings['progress']['size']; ?>">
				<span class="circle-progress-site-2">
					<span class="circle-progress-graph"></span>
				</span>
				<span class="circle-progress-site-1">
					<span class="circle-progress-graph"></span>
				</span>
				<div class="circle-progress-value">
					<?php echo $settings['progress']['size']; ?>
					<span>%</span>
				</div>
			</div>
			<div class="progress-title">
				<h2><?php echo $settings['title']; ?></h2>
			</div>
		</div>
	    <?php
	}
}