<?php
if(!defined('ABSPATH')) exit;
class TeamSection extends \Elementor\Widget_Base {
    public function get_name() {
        return 'team_section';
    }
    public function get_title() {
        return esc_html__( 'Team Section', 'elementor-webtheme' );
    }
    public function get_icon() {
        return 'eicon-person';
    }
    public function get_categories() {
        return [ 'elementor-webtheme-category' ];
    }
    public function get_keywords() {
        return [ 'team' ];
    }
    protected function register_controls() {
        $this->start_controls_section(
            'image_section',
            [
                'label' => esc_html__( 'Team Image', 'elementor-webtheme' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
            $this->add_control(
                'image',
                [
                    'label' => esc_html__( 'Choose Team Image', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section(
            'text_section',
            [
                'label' => esc_html__( 'Team Text', 'elementor-webtheme' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
            $this->add_control(
                'team_name',
                [
                    'label' => esc_html__( 'Member Name', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'Team Name here', 'elementor-webtheme' ),
                    'placeholder' => esc_html__( 'Enter name here', 'elementor-webtheme' ),
                    'label_block' => true,
                ]
            );
            $this->add_control(
                'team_designation',
                [
                    'label' => esc_html__( 'Member Designation', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__( 'Designation', 'elementor-webtheme' ),
                    'placeholder' => esc_html__( 'Enter Member Designation', 'elementor-webtheme' ),
                    'label_block' => true,
                ]
            );
            $repeater = new \Elementor\Repeater();

            $repeater->add_control(
                'social_icon',
                [
                    'label' => esc_html__( 'Team Social Icon', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'default' => [
                        'value' => 'fab fa-wordpress',
                        'library' => 'fa-brands',
                    ],
                    'recommended' => [
                        'fa-brands' => [
                            'behance',
                            'codepen',
                            'dribbble',
                            'elementor',
                            'facebook',
                            'github',
                            'gitlab',
                            'instagram',
                            'linkedin',
                            'pinterest',
                            'skype',
                            'telegram',
                            'twitter',
                            'vimeo',
                            'whatsapp',
                            'wordpress',
                            'youtube',
                        ],
                        'fa-solid' => [
                            'envelope',
                            'link',
                            'rss',
                        ],
                    ],
                ]
            );
            $repeater->add_control(
                'social_link',
                [
                    'label' => esc_html__( 'Link', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::URL,
                    'placeholder' => esc_html__( 'https://your-link.com', 'elementor-webtheme' ),
                    'options' => [ 'url', 'is_external', 'nofollow' ],
                    'default' => [
                        'url' => '',
                        'is_external' => true,
                        'nofollow' => true,
                    ],
                    'label_block' => true,
                ]
            );
            $this->add_control(
                'list',
                [
                    'label' => esc_html__( 'Media Social List', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::REPEATER,
                    'fields' => $repeater->get_controls(),
                    'default' => [
                        [
                            'social_icon' => [
                                'value' => 'fab fa-facebook',
                                'library' => 'fa-brands',
                            ],
                        ],
                        [
                            'social_icon' => [
                                'value' => 'fab fa-twitter',
                                'library' => 'fa-brands',
                            ],
                        ],
                        [
                            'social_icon' => [
                                'value' => 'fab fa-youtube',
                                'library' => 'fa-brands',
                            ],
                        ],
                    ],
                    'title_field' => '<# var migrated = "undefined" !== typeof __fa4_migrated, social = ( "undefined" === typeof social ) ? false : social; #>{{{ elementor.helpers.getSocialNetworkNameFromIcon( social_icon, social, true, migrated, true ) }}}',
                ]
            );

        $this->end_controls_section();

        /*---------  Team css style start here  --------*/

        $this->start_controls_section(
            'section_option',
            [
                'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'select_option',
                [
                    'label' => __( 'Select Your Option', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'options' => [
                        'one' => __( 'One', 'elementor-webtheme' ),
                        'two' => __( 'Two', 'elementor-webtheme' ),
                    ],
                    'default' => 'one',
                    
                ]
            );

            $this->add_responsive_control(
                'text_align',
                [
                    'label' => __( 'Alignment', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::CHOOSE,
                    'options' => [
                        'left' => [
                            'title' => __( 'Left', 'elementor-webtheme' ),
                            'icon' => 'eicon-text-align-left',
                        ],
                        'center' => [
                            'title' => __( 'Center', 'elementor-webtheme' ),
                            'icon' => 'eicon-text-align-center',
                        ],
                        'right' => [
                            'title' => __( 'Right', 'elementor-webtheme' ),
                            'icon' => 'eicon-text-align-right',
                        ],
                        'justify' => [
                            'title' => __( 'Justified', 'elementor-webtheme' ),
                            'icon' => 'eicon-text-align-justify',
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section' => 'text-align: {{VALUE}};',
                    ],
                ]
            );
        $this->end_controls_section();

        $this->start_controls_section(
			'single_box_section_style',
			[
				'label' => __( 'Single Box css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'single_box_bg_color',
			[
				'label' => __( 'Single Box BG Color', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .team-section' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'hover_single_bg_color',
			[
				'label' => __( 'Hover Box BG Color', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'selectors' => [
					'{{WRAPPER}} .team-section:hover' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'single_border',
				'label' => __( 'Single Box Border', 'elementor-webtheme' ),
				'selector' => '{{WRAPPER}} .team-section',
			]
		);
		$this->add_responsive_control(
			'single_border_radius',
			[
				'label' => __( 'Box Border Radius', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .team-section' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name' => 'hover_single_border',
				'label' => __( 'Hover Box Border', 'elementor-webtheme' ),
				'selector' => '{{WRAPPER}} .team-section:hover',
			]
		);
		$this->add_responsive_control(
			'hover_box_border_radius',
			[
				'label' => __( 'Hover Box Border Radius', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .team-section:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'single_box_padding',
			[
				'label' => __( 'Single Box Padding', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .team-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
		$this->add_responsive_control(
			'single_box_margin',
			[
				'label' => __( 'Single Box Margin', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .team-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator' => 'before',
			]
		);
		$this->end_controls_section();

        $this->start_controls_section(
            'name_style',
            [
                'label' => esc_html__( 'Member Name css', 'elementor-webtheme' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_control(
                'name_color',
                [
                    'label' => esc_html__( 'Name Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-member-name h1' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'name_typography',
                    'selector' => '{{WRAPPER}} .team-section .team-member-name h1',
                ]
            );
            $this->add_responsive_control(
                'name_padding',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Name Padding', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-member-name h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_responsive_control(
                'name_margin',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Name Margin', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-member-name h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'designation_style',
            [
                'label' => esc_html__( 'Designation css', 'elementor-webtheme' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_control(
                'designation_color',
                [
                    'label' => esc_html__( 'Designation Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .team-section .member-designation h3' => 'color: {{VALUE}};',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'designation_typography',
                    'selector' => '{{WRAPPER}} .team-section .member-designation h3',
                ]
            );
            $this->add_responsive_control(
                'designation_padding',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Designation Padding', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section .member-designation h3' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_responsive_control(
                'designation_margin',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Designation Margin', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section .member-designation h3' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'social_icon_style',
            [
                'label' => __( 'Social Icon css', 'elementor-webtheme' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
        $this->start_controls_tabs(
            'style_tabs'
        );
        $this->start_controls_tab(
            'style_normal_tab',
            [
                'label' => __( 'Normal', 'elementor-webtheme' ),
            ]
        );

            $this->add_control(
                'icon_color',
                [
                    'label' => __( 'Icon Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-media-icon li a i' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                'icon_background_color',
                [
                    'label' => __( 'Background Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-media-icon li a i' => 'background: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'icon_border',
                    'label' => __( 'Icon Border', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .team-section .team-media-icon li a i',
                ]
            );
            $this->add_responsive_control(
                'icon_border_radius',
                [
                    'label' => __( 'Icon Border Radius', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-media-icon li a i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
        $this->end_controls_tab();

        $this->start_controls_tab(
            'style_hover_tab',
            [
                'label' => __( 'Hover', 'elementor-webtheme' ),
            ]
        );

            $this->add_control(
                'hover_icon_color',
                [
                    'label' => __( 'Icon Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-media-icon li a i:hover' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                'hover_icon_background_color',
                [
                    'label' => __( 'Background Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-media-icon li a i:hover' => 'background: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'hover_border',
                    'label' => __( 'Hover Border', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .team-section .team-media-icon li a i:hover',
                ]
            );
            $this->add_responsive_control(
                'hover_icon_border_radius',
                [
                    'label' => __( 'Border Radius', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-media-icon li a i:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
        $this->end_controls_tab();

        $this->end_controls_tabs();

            $this->add_responsive_control(
                'icon_padding',
                [
                    'label' => __( 'Icon Padding', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-media-icon li a i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'icon_margin',
                [
                    'label' => __( 'Icon Margin', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-media-icon li a i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'height',
                [
                    'label' => __( 'Height', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-media-icon li a i' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_control(
                'width',
                [
                    'label' => __( 'Width', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .team-section .team-media-icon li a i' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'icon_typography',
                    'selector' => '{{WRAPPER}} .team-section .team-media-icon li a i',
                ]
            );
            
        $this->end_controls_section();

    }
    protected function render() {

        $settings = $this->get_settings_for_display();

        ?>
        <?php if($settings['select_option']=='one'){ ?>
            <div class="team-section option1">
                <div class="team-member-image">
                    <img src="<?php echo $settings['image']['url']; ?>" alt="">
                    <div class="team-member-content">
                        <div class="team-member-name">
                            <h1><?php echo $settings['team_name']; ?></h1>
                        </div>
                        <div class="member-designation">
                            <h3><?php echo $settings['team_designation']; ?></h3>
                            <ul class="team-media-icon">
                                <?php foreach (  $settings['list'] as $item ) { ?>
                                    <li><a href="<?php echo esc_url($item['social_link']['url']); ?>"><?php \Elementor\Icons_Manager::render_icon( $item['social_icon'], [ 'aria-hidden' => 'true' ] ); ?></a></li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        <?php }elseif($settings['select_option']=='two'){ ?>
            <div class="team-section option2">
            <div class="team-member-image">
                    <img src="<?php echo $settings['image']['url']; ?>" alt="">
                    <div class="team-member-content">
                        <div class="team-member-name">
                            <h1><?php echo $settings['team_name']; ?></h1>
                        </div>
                        <div class="member-designation">
                            <h3><?php echo $settings['team_designation']; ?></h3>
                            <ul class="team-media-icon">
                                <?php foreach (  $settings['list'] as $item ) { ?>
                                    <li><a href="<?php echo esc_url($item['social_link']['url']); ?>"><?php \Elementor\Icons_Manager::render_icon( $item['social_icon'], [ 'aria-hidden' => 'true' ] ); ?></a></li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        <?php } ?>
        <?php
    }
}