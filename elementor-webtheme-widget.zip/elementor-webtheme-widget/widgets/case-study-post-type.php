<?php
use Elementor\Group_Control_Typography;
if(!defined('ABSPATH')) exit;
class CaseStudyPostType extends \Elementor\Widget_Base{
	public function get_name(){
		return "casestudy_post_type";
	}
	public function get_title(){
		return "Case Study";
	}
	public function get_icon(){
		return "eicon-share";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){

		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Case Study Button', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'button_text',
				[
					'label' => __( 'Button Text', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter Button Text', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'Learn More', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'show_button',
				[
					'label' => __( 'Show Button', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SWITCHER,
					'label_on' => __( 'Show', 'elementor-webtheme' ),
					'label_off' => __( 'Hide', 'elementor-webtheme' ),
					'return_value' => 'yes',
					'default' => 'yes',
				]
			);
			$this->add_control(
				'button_icon',
				[
					'label' => __( 'Button Icon', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::ICONS,
					'default' => [
						'value' => 'fa fa-angle-right',
						'library' => 'solid',
					],
				]
			);
		$this->end_controls_section();

        /*---------  Case Study Post Type Section css style start here  --------*/
		$this->start_controls_section(
			'section_option',
			[
				'label' => __( 'Choose Option', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'select_option',
				[
					'label' => __( 'Select Your Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
					],
					'default' => 'one',
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'title_section',
			[
				'label' => __( 'Title css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->start_controls_tabs(
				'title_style_tabs'
			);
				$this->start_controls_tab(
					'title_style_normal_tab',
					[
						'label' => __( 'Normal', 'elementor-webtheme' ),
					]
				);
					$this->add_control(
						'title_color',
						[
							'label' => __( 'Title Color', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .case-study-content .case-study-title h1 a' => 'color: {{VALUE}};',
							],
						]
					);
				
				$this->end_controls_tab();
				
				$this->start_controls_tab(
					'title_style_hover_tab',
					[
						'label' => __( 'Hover', 'elementor-webtheme' ),
					]
				);

					$this->add_control(
						'hover_title_color',
						[
							'label' => __( 'Hover Color', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::COLOR,
							'default' => '',
							'selectors' => [
								'{{WRAPPER}} .case-study-content .case-study-title h1 a:hover' => 'color: {{VALUE}};',
							],
						]
					);
				
				$this->end_controls_tab();
				
			$this->end_controls_tabs();

			$this->add_responsive_control(
				'title_padding',
				[
					'label' => __( 'Title Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .case-study-content .case-study-title h1 ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Title Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .case-study-content .case-study-title h1 ' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
	        $this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'label' => esc_html__( 'Title Typography', 'elementor-webtheme' ),
					'selector' => 
	                    '{{WRAPPER}} .case-study-content .case-study-title h1 a',
				]
			);

		$this->end_controls_section();

		$this->start_controls_section(
			'category_section',
			[
				'label' => __( 'Category css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'category_color',
				[
					'label' => __( 'Category Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .case-study-content .case-study-category a' => 'color: {{VALUE}};',
					],
				]
			);

	        $this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'category_typography',
					'label' => esc_html__( 'Category Typography', 'elementor-webtheme' ),
					'selector' => 
	                    '{{WRAPPER}} .case-study-content .case-study-category a',
				]
			);
			$this->add_responsive_control(
				'category_padding',
				[
					'label' => __( 'Category Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .case-study-content .case-study-category a ' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
		$this->end_controls_section();
		$this->start_controls_section(
			'button_css',
			[
				'label' => esc_html__( 'Button css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'button_typography',
					'selector' => '{{WRAPPER}} .case-study-button a',
				]
			);
			$this->start_controls_tabs(
				'style_tabs'
			);

			$this->start_controls_tab(
				'style_normal_tab',
				[
					'label' => esc_html__( 'Normal', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'text_color',
				[
					'label' => esc_html__( 'Button Text Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .case-study-button a' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'background',
					'label' => esc_html__( 'Button Background', 'elementor-webtheme' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .case-study-button a',
				]
			);
			$this->end_controls_tab();

			$this->start_controls_tab(
				'style_hover_tab',
				[
					'label' => esc_html__( 'Hover', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'text_hover_color',
				[
					'label' => esc_html__( 'Hover Text Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .case-study-button a:hover' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Background::get_type(),
				[
					'name' => 'hover_background',
					'label' => esc_html__( 'Hover Background', 'elementor-webtheme' ),
					'types' => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .case-study-button a:hover',
				]
			);
			$this->end_controls_tab();

			$this->end_controls_tabs();

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'button_border',
					'label' => esc_html__( 'Button Border', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .case-study-button a',
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'button_border_radius',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Button Border Radius', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .case-study-button a' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'box_shadow',
					'label' => esc_html__( 'Button Box Shadow', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .case-study-button a',
				]
			);
			$this->add_responsive_control(
				'button_padding',
				[
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'label' => esc_html__( 'Button Padding', 'elementor-webtheme' ),
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .case-study-button a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
	}

	protected function render(){

		$settings = $this->get_settings_for_display();

		?>
			<?php if($settings['select_option']=='one'){ ?>

			<div class="case-study-post-type-section">
				<div class=" owl-carousel owl-loaded case_study_carousel_one">
					<?php $the_query = new \WP_Query( array(
						 	'post_type' => 'case_study_post',
						 	'posts_per_page' => 6,
					        'order' =>'DSC',
					        // 'post__in' => array(926, 925, 924 ),
						  ) ); ?>
					<?php while ($the_query->have_posts()) : $the_query->the_post();
						$terms = get_the_terms(get_the_ID(), 'case_study_post_category');
					?>
					<div class="col-md-12 col-xs-12 col-sm-12" >
						<div class="single-case-study-post-type">
							<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
								<?php if(has_post_thumbnail()){?>
									<div class="case-study-thumb">
										<a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail(); ?></a>
										<div class="case-study-content">
											<div class="case-study-category">
												<?php if( $terms ){
													foreach( $terms as $single_slugs ){?>
														<a href="<?php the_permalink(); ?>"><?php echo $single_slugs->name ;?></a>
												<?php }} ?>
											</div>
											<div class="case-study-title">
												<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
											</div>
											<div class="case-study-button">
												<?php if( 'yes'===$settings['show_button'] ){ ?>
													<a href="<?php the_permalink(); ?>">
														<?php echo $settings['button_text']; ?>
														<?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
													</a>
												<?php } ?>
											</div>
										</div>
									</div>
								<?php } ?>
							</div>
						</div>
					</div>
					<?php endwhile; ?>
					<?php wp_reset_query(); ?>
				</div>
			</div>
			<script>
			jQuery(document).ready(function($) {
				"use strict";

					$('.case_study_carousel_one').owlCarousel({
        				loop: true,
        				autoplay: true,
        				autoplayTimeout: 10000,
        				dots: true,
						margin:30,
        				dotsEeach:true,
        				nav: false,
        				navText: ["", ""],
        				responsive: {
        					0: {
        						items: 1
        					},
        					768: {
        						items: 2
        					},
        					991: {
        						items: 2
        					},
        					992: {
        						items: 2
        					},
        					1000: {
        						items: 3
        					},
        					1365: {
        						items: 3
        					},
        					1500: {
        						items: 4
        					},
        					1920: {
        						items: 4
        					}
        				}
        			})		
        		});
        	</script>
			<?php }elseif($settings['select_option']=='two'){ ?>

				<div class="case-study-post-type-section">
				<div class=" owl-carousel owl-loaded case_study_carousel_two">
					<?php $the_query = new \WP_Query( array(
						'post_type' => 'case_study_post',
						'posts_per_page' => 6,
						'order' =>'DSC',
						//'post__in' => array(926, 925, 924 ),
						) ); ?>
					<?php while ($the_query->have_posts()) : $the_query->the_post();
						$terms = get_the_terms(get_the_ID(), 'case_study_post_category');
					?>
					<div class="col-md-12 col-xs-12 col-sm-12" >
						<div class="single-case-study-post-type option2">
							<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
								<?php if(has_post_thumbnail()){?>
									<div class="case-study-thumb">
										<a href="<?php the_permalink(); ?>"> <?php the_post_thumbnail(); ?></a>
										
									</div>
									<div class="case-study-content">
											<div class="case-study-category">
												<?php if( $terms ){
													foreach( $terms as $single_slugs ){?>
														<a href="<?php the_permalink(); ?>"><?php echo $single_slugs->name ;?></a>
												<?php }} ?>
											</div>
											<div class="case-study-title">
												<h1><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
											</div>
											<div class="case-study-button">
												<?php if( 'yes'===$settings['show_button'] ){ ?>
													<a href="<?php the_permalink(); ?>">
														<?php echo $settings['button_text']; ?>
														<?php \Elementor\Icons_Manager::render_icon( $settings['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
													</a>
												<?php } ?>
											</div>
										</div>
								<?php } ?>
							</div>
						</div>
					</div>
					<?php endwhile; ?>
					<?php wp_reset_query(); ?>
				</div>
			</div>

			<script>
			jQuery(document).ready(function($) {
				"use strict";

					$('.case_study_carousel_two').owlCarousel({
        				loop: true,
        				autoplay: true,
        				autoplayTimeout: 10000,
        				dots: true,
        				dotsEeach:true,
        				nav: false,
        				navText: ["", ""],
        				responsive: {
        					0: {
        						items: 1
        					},
        					768: {
        						items: 2
        					},
        					991: {
        						items: 2
        					},
        					992: {
        						items: 2
        					},
        					1000: {
        						items: 3
        					},
        					1365: {
        						items: 3
        					},
        					1920: {
        						items: 3
        					}
        				}
        			})		
        		});
        	</script>
			<?php }?>
		<?php
	}
}