<?php
if(!defined('ABSPATH')) exit;
class TestimonialSection extends \Elementor\Widget_Base{
	public function get_name(){
		return "testimonial_section";
	}
	public function get_title(){
		return "Testimonial Section";
	}
	public function get_icon(){
		return "eicon-blockquote";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){

		$this->start_controls_section(
			'slider', [
				'label' => __( 'Testimonial Slider', 'elementor-webtheme' ),
			]
		);
			$repeater = new \Elementor\Repeater();
			$repeater->add_control(
				'testi_image',
				[
					'label' => esc_html__( 'Choose Quote Image', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				]
			);
			$repeater->add_control(
				'image',
				[
					'label' => esc_html__( 'Choose Thumb Image', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
					'default' => [
						'url' => \Elementor\Utils::get_placeholder_image_src(),
					],
				]
			);
			$repeater->add_control(
				'testi_title',
				[
					'label' => esc_html__( 'Testi Title', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Grate Services', 'elementor-webtheme' ),
					'placeholder' => esc_html__( 'Enter Title', 'elementor-webtheme' ),
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'testi_description',
				[
					'label' => esc_html__( 'Testi Description', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'rows' => 6,
					'default' => esc_html__( 'Testimonial Description. You Can Change this description no problem.', 'elementor-webtheme' ),
					'placeholder' => esc_html__( 'Enter Testi Description', 'elementor-webtheme' ),
				]
			);
			$repeater->add_control(
				'testimonial_name',
				[
					'label' => esc_html__( 'Testimonial Name', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Deo Alexson', 'elementor-webtheme' ),
					'placeholder' => esc_html__( 'Enter Testimonial Name', 'elementor-webtheme' ),
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'testimonial_designation',
				[
					'label' => esc_html__( 'Testi Designation', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'default' => esc_html__( 'Web Developer', 'elementor-webtheme' ),
					'placeholder' => esc_html__( 'Enter Designation', 'elementor-webtheme' ),
					'label_block' => true,
				]
			);
			$repeater->add_control(
				'testi_rating',
				[
					'label' => esc_html__( 'Testi Rating', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::NUMBER,
					'min' => 1,
					'max' => 5,
					'step' => 1,
					'default' => 5,
				]
			);
			$this->add_control(
				'slides',
				[
					'label' => esc_html__( 'Testimonial List', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'name' => esc_html__( 'Testimonial Name', 'elementor-webtheme' ),
							'quote_text' => esc_html__( 'Testimonial Description. You Can Change this description no problem.', 'elementor-webtheme' ),
						],
						[
							'name' => esc_html__( 'Testimonial Name Two', 'elementor-webtheme' ),
							'quote_text' => esc_html__( 'Testimonial Description. You Can Change this description no problem.', 'elementor-webtheme' ),
						],
					],
					'title_field' => '{{{ name }}}',
				]
			);

		$this->end_controls_section();

        /*---------  Testimonial Section css style start here  --------*/

        $this->start_controls_section(
            'section_option',
            [
                'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'select_option',
                [
                    'label' => __( 'Select Your Option', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'options' => [
                        'one' => __( 'One', 'elementor-webtheme' ),
                        'two' => __( 'Two', 'elementor-webtheme' ),
                    ],
                    'default' => 'one',
                    
                ]
            );
		$this->end_controls_section();

		$this->start_controls_section(
			'content_section_style',
			[
				'label' => __( 'Text & Rating css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .testimonial-title h2' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .testimonial-title h2',
				]
			);
			$this->add_control(
				'name_color',
				[
					'label' => __( 'Name Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .testimonial-single-content .about-author h1' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'name_typography',
					'selector' => '{{WRAPPER}} .testimonial-single-content .about-author h1',
				]
			);
			$this->add_responsive_control(
                'name_padding',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Name Padding', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .testimonial-single-content .about-author h1' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
			$this->add_control(
				'designation_color',
				[
					'label' => __( 'Designation Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'separator' => 'before',
					'selectors' => [
						'{{WRAPPER}} .testimonial-single-content .about-author h3' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'designation_typography',
					'selector' => '{{WRAPPER}} .testimonial-single-content .about-author h3',
				]
			);

			$this->add_control(
				'description_color',
				[
					'label' => __( 'Description Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'separator' => 'before',
					'selectors' => [
						'{{WRAPPER}} .testimonial-single-content .testi-description p' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'selector' => '{{WRAPPER}} .testimonial-single-content .testi-description p',
				]
			);
			$this->add_responsive_control(
                'description_padding',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Description Padding', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .testimonial-single-content .testi-description p' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

			$this->add_control(
				'rating_color',
				[
					'label' => __( 'Rating Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'separator' => 'before',
					'selectors' => [
						'{{WRAPPER}} .testimonial-single-content .testimonial-star i.active' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_responsive_control(
                'rating_padding',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Rating Padding', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .testimonial-single-content .testimonial-star i' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
		$this->end_controls_section();
		$this->start_controls_section(
			'box_section_style',
			[
				'label' => __( 'Single Box css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->start_controls_tabs(
				'box_style_tabs'
			);
				$this->start_controls_tab(
					'box_style_normal_tab',
					[
						'label' => __( 'Normal', 'elementor-webtheme' ),
					]
				);
				
					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'box_border',
							'label' => __( 'Box Border', 'elementor-webtheme' ),
							'selector' => '{{WRAPPER}} .testimonial-single-content',
						]
					);

					$this->add_responsive_control(
						'box_border_radius',
						[
							'label' => __( 'Box Border Radius', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .testimonial-single-content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'box_shadow',
							'label' => __( 'Box Shadow', 'elementor-webtheme' ),
							'selector' => '{{WRAPPER}} .testimonial-single-content',
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Background::get_type(),
						[
							'name' => 'box_background',
							'label' => __( 'Box Background', 'elementor-webtheme' ),
							'types' => [ 'classic', 'gradient', 'video' ],
							'selector' => '{{WRAPPER}} .testimonial-single-content',
						]
					);
					$this->add_responsive_control(
						'box_padding',
						[
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'label' => esc_html__( 'Box Padding', 'elementor-webtheme' ),
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .testimonial-single-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
					$this->add_responsive_control(
						'box_margin',
						[
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'label' => esc_html__( 'Box Margin', 'elementor-webtheme' ),
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .testimonial-single-content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);
				$this->end_controls_tab();
				
				$this->start_controls_tab(
					'box_style_hover_tab',
					[
						'label' => __( 'Hover', 'elementor-webtheme' ),
					]
				);

					$this->add_group_control(
						\Elementor\Group_Control_Border::get_type(),
						[
							'name' => 'hover_box_border',
							'label' => __( 'Box Border', 'elementor-webtheme' ),
							'selector' => '{{WRAPPER}} .testimonial-single-content:hover',
						]
					);

					$this->add_responsive_control(
						'hover_box_border_radius',
						[
							'label' => __( 'Box Border Radius', 'elementor-webtheme' ),
							'type' => \Elementor\Controls_Manager::DIMENSIONS,
							'size_units' => [ 'px', 'em', '%' ],
							'selectors' => [
								'{{WRAPPER}} .testimonial-single-content:hover' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
							],
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Box_Shadow::get_type(),
						[
							'name' => 'hover_box_shadow',
							'label' => __( 'Box Shadow', 'elementor-webtheme' ),
							'selector' => '{{WRAPPER}} .testimonial-single-content:hover',
						]
					);

					$this->add_group_control(
						\Elementor\Group_Control_Background::get_type(),
						[
							'name' => 'hover_box_background',
							'label' => __( 'Box Background', 'elementor-webtheme' ),
							'types' => [ 'classic', 'gradient', 'video' ],
							'selector' => '{{WRAPPER}} .testimonial-single-content:hover',
						]
					);
					
				$this->end_controls_tab();
				
			$this->end_controls_tabs();

			$this->add_responsive_control(
				'box_margin',
				[
					'label' => __( 'Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .testimonial .testimonial-item .inner_box:hover' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'box_padding',
				[
					'label' => __( 'Padding', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .testimonial .testimonial-item .inner_box:hover' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
		
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slides = isset($settings['slides']) ? $settings['slides'] : '';
		?>
		<?php if($settings['select_option']=='one'){ ?>
			<div class="testimonial-section option1">
				<div class="testimonial-section-carousel1 owl-carousel">
					<?php foreach ($slides as $slide) { ?>
						<div class="testimonial-single-content">
							<div class="testimonial-img-desc-content">
								<div class="testimonial-image">
									<img src="<?php echo $slide['testi_image']['url']; ?>" alt="">
								</div>
								<div class="testimonial-title">
									<h2><?php echo $slide['testi_title']; ?></h2>
								</div>
								
								<div class="testimonial-rating">
									<?php if( $slide['testi_rating']==5 ){ ?>
										<div class="testimonial-star">
											<i class="fa fa-star active"></i>
											<i class="fa fa-star active"></i>
											<i class="fa fa-star active"></i>
											<i class="fa fa-star active"></i>
											<i class="fa fa-star active"></i>
										</div>
									<?php } ?>
									<?php if( $slide['testi_rating']==4 ){ ?>
										<div class="testimonial-star">
											<i class="fa fa-star active"></i>
											<i class="fa fa-star active"></i>
											<i class="fa fa-star active"></i>
											<i class="fa fa-star active"></i>
											<i class="fa fa-star"></i>
										</div>
									<?php } ?>
									<?php if( $slide['testi_rating']==3 ){ ?>
										<div class="testimonial-star">
											<i class="fa fa-star active"></i>
											<i class="fa fa-star active"></i>
											<i class="fa fa-star active"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
										</div>												
									<?php } ?>
									<?php if( $slide['testi_rating']==2 ){ ?>
										<div class="testimonial-star">
											<i class="fa fa-star active"></i>
											<i class="fa fa-star active"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
										</div>												
									<?php } ?>
									<?php if( $slide['testi_rating']==1 ){ ?>
										<div class="testimonial-star">
											<i class="fa fa-star active"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
											<i class="fa fa-star"></i>
										</div>
									<?php } ?>
								</div>
								<div class="testi-description">
									<p><?php echo $slide['testi_description']; ?></p>
								</div>
							</div>
							<div class="author-info">
								<div class="author-image">
									<img src="<?php echo $slide['image']['url']; ?>" alt="">
								</div>
								<div class="about-author">
									<h1><?php echo $slide['testimonial_name']; ?></h1>
									<h3><?php echo $slide['testimonial_designation']; ?></h3>
								</div>
							</div>
						</div>
					<?php } ?>
				</div>
			</div>
			<script>
				jQuery(document).ready(function($) {
					"use strict";
					$('.testimonial-section-carousel1').owlCarousel({
						loop: true,
						autoplay: false,
						autoplayTimeout: 10000,
						margin: 20,
						dots: true,
						nav: false,
						items: 3,
						navText: ["<i class='flaticon-back-1'></i>", "<i class='fa fa-angle-right'></i>"],
						responsive: {
							0: {
								items: 1
							},
							768: {
								items: 1
							},
							992: {
								items: 2
							},
							1025: {
								items: 2
							},
							1365: {
								items: 2
							},
							1600: {
								items: 3
							},
							1920: {
								items: 3
							}
						}
					})
				});

			</script>

		<?php }elseif($settings['select_option']=='two'){ ?>

			<div class="testimonial option2">
				<div class="testimonial-carousel2 owl-carousel">
					<?php foreach ($slides as $slide) { ?>
						<div class="testimonial-single-content">
							<div class="testimonial-image">
								<img src="<?php echo $slide['testi_image']['url']; ?>" alt="">
							</div>
							<div class="testimonial-title">
								<h2><?php echo $slide['testi_title']; ?></h2>
							</div>
							<div class="testimonial-rating">
								<?php if( $slide['testi_rating']==5 ){ ?>
									<div class="testimonial-star">
										<i class="fa fa-star active"></i>
										<i class="fa fa-star active"></i>
										<i class="fa fa-star active"></i>
										<i class="fa fa-star active"></i>
										<i class="fa fa-star active"></i>
									</div>
								<?php } ?>
								<?php if( $slide['testi_rating']==4 ){ ?>
									<div class="testimonial-star">
										<i class="fa fa-star active"></i>
										<i class="fa fa-star active"></i>
										<i class="fa fa-star active"></i>
										<i class="fa fa-star active"></i>
										<i class="fa fa-star"></i>
									</div>
								<?php } ?>
								<?php if( $slide['testi_rating']==3 ){ ?>
									<div class="testimonial-star">
										<i class="fa fa-star active"></i>
										<i class="fa fa-star active"></i>
										<i class="fa fa-star active"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
									</div>												
								<?php } ?>
								<?php if( $slide['testi_rating']==2 ){ ?>
									<div class="testimonial-star">
										<i class="fa fa-star active"></i>
										<i class="fa fa-star active"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
									</div>												
								<?php } ?>
								<?php if( $slide['testi_rating']==1 ){ ?>
									<div class="testimonial-star">
										<i class="fa fa-star active"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
										<i class="fa fa-star"></i>
									</div>
								<?php } ?>
							</div>
							<div class="testi-description">
								<p><?php echo $slide['testi_description']; ?></p>
							</div>
							<div class="author-image">
								<img src="<?php echo $slide['image']['url']; ?>" alt="">
								<div class="about-author">
									<h1><?php echo $slide['testimonial_name']; ?></h1>
									<h3><?php echo $slide['testimonial_designation']; ?></h3>
								</div>
							</div>
						</div>
					<?php } ?>

				</div>
			</div>
			<script>
				jQuery(document).ready(function($) {
					"use strict";
					$('.testimonial-carousel2').owlCarousel({
						loop: true,
						autoplay: false,
						autoplayTimeout: 10000,
						margin: 0,
						dots: false,
						nav: false,
						items: 6,
						navText: ["<i class='flaticon-back-1'></i>", "<i class='fa fa-angle-right'></i>"],
						responsive: {
							0: {
								items: 1
							},
							768: {
								items: 1
							},
							992: {
								items: 1
							},
							1364: {
								items: 2
							},
							1920: {
								items: 3
							}
						}
					})
				});
			</script>
		<?php }?>
		<?php
	}
}