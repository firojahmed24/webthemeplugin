<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if(!defined('ABSPATH')) exit;
class TeamSlideSection extends Widget_Base{
	public function get_name(){
		return "teamslidesection";
	}
	public function get_title(){
		return "Team Slide";
	}
	public function get_icon(){
		return "eicon-slides";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
		$this->start_controls_section(
			'slider', [
				'label' => __( 'Team Slider', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'slides', [
				'label' => __( 'Team Member Slide', 'elementor-webtheme' ),
				'type' => Controls_Manager::REPEATER,
				'name_field' => '{{{member_name_text}}}',
				'fields' => [
					[
						'name' => 'select_img',
					    'label' => esc_html__('Member Image','elementor-webtheme'),
					    'type'=>Controls_Manager::MEDIA,
					    'default' => [
						  'url' => \Elementor\Utils::get_placeholder_image_src(),
					    ],
					],
					[
						'name' => 'member_name_text',
						'label' => __( 'Member Name', 'elementor-webtheme' ),
						'type' => Controls_Manager::TEXT,
						'dynamic' => [
							'active' => true,
						],
						'placeholder' => __( 'Enter Member Name', 'elementor-webtheme' ),
						'label_block' => true,
						'default' => __( 'Abdur Rahman', 'elementor-webtheme' ),
					],
					[
						'name' => 'member_designation_text',
						'label' => __( 'Member Designation', 'elementor-webtheme' ),
						'type' => Controls_Manager::TEXTAREA,
						'dynamic' => [
							'active' => true,
						],
						'placeholder' => __( 'Member Designation', 'elementor-webtheme' ),
						'default' => __( 'WordPress Developer', 'elementor-webtheme' ),
					],
				],
			]
		);
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'social_media_icon',
			[
				'label' => esc_html__( 'Media Icon', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value' => 'fab fa-wordpress',
					'library' => 'fa-brands',
				],
				'recommended' => [
					'fa-brands' => [
						'android',
						'apple',
						'behance',
						'bitbucket',
						'codepen',
						'delicious',
						'deviantart',
						'digg',
						'dribbble',
						'elementor',
						'facebook',
						'flickr',
						'foursquare',
						'free-code-camp',
						'github',
						'gitlab',
						'globe',
						'houzz',
						'instagram',
						'jsfiddle',
						'linkedin',
						'medium',
						'meetup',
						'mix',
						'mixcloud',
						'odnoklassniki',
						'pinterest',
						'product-hunt',
						'reddit',
						'shopping-cart',
						'skype',
						'slideshare',
						'snapchat',
						'soundcloud',
						'spotify',
						'stack-overflow',
						'steam',
						'telegram',
						'thumb-tack',
						'tripadvisor',
						'tumblr',
						'twitch',
						'twitter',
						'viber',
						'vimeo',
						'vk',
						'weibo',
						'weixin',
						'whatsapp',
						'wordpress',
						'xing',
						'yelp',
						'youtube',
						'500px',
					],
					'fa-solid' => [
						'envelope',
						'link',
						'rss',
					],
				],
			]
		);
		$repeater->add_control(
			'social_link',
			[
				'label' => esc_html__( 'Media Link', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'elementor-webtheme' ),
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => '',
					'is_external' => true,
					'nofollow' => true,
				],
				'label_block' => true,
			]
		);
		$this->add_control(
			'list',
			[
				'label' => esc_html__( 'Social Media', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::REPEATER,
				'fields' => $repeater->get_controls(),
				'default' => [
					[
						'social_media_icon' => [
							'value' => 'fab fa-facebook',
							'library' => 'fa-brands',
						],
					],
					[
						'social_media_icon' => [
							'value' => 'fab fa-youtube',
							'library' => 'fa-brands',
						],
					],
				],
				'title_field' => '<# var migrated = "undefined" !== typeof __fa4_migrated, social = ( "undefined" === typeof social ) ? false : social; #>{{{ elementor.helpers.getSocialNetworkNameFromIcon( social_media_icon, social, true, migrated, true ) }}}',
			]
		);
		$this->end_controls_section();

		/*---------  Team slide css style start here  --------*/

		$this->start_controls_section(
		'section_option',
		[
			'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
			'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
		]
		);
		$this->add_control(
			'select_option',
			[
				'label' => __( 'Select Your Option', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'one' => __( 'One', 'elementor-webtheme' ),
				],
				'default' => 'one',
				
			]
		);
		$this->end_controls_section();
		$this->start_controls_section(
			'icon_section_style',
			[
				'label' => __( 'Media css', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'style_tabs'
		);
		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => __( 'Normal', 'elementor-webtheme' ),
			]
		);
			$this->add_control(
				'primary_color',
				[
					'label' => __( 'Icon Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .team-slide .team-slide-media-icon li a i' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'background_color',
				[
					'label' => __( 'Icon BG Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .team-slide .team-slide-media-icon li a i' => 'background-color: {{VALUE}};',
					],
				]
			);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => __( 'Hover', 'elementor-webtheme' ),
			]
		);
			$this->add_control(
				'hover_primary_color',
				[
					'label' => __( 'Icon Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .team-slide:hover .team-slide-media-icon li a i' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'hover_background_color',
				[
					'label' => __( 'Icon BG Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .team-slide:hover .team-slide-media-icon li a i' => 'background-color: {{VALUE}};',
					],
				]
			);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		$this->start_controls_section(
			'content_section_style',
			[
				'label' => __( 'Team Text css', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'name' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'name' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'name' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'name' => __( 'Justified', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .team-slide' => 'text-align: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'heading_name',
				[
					'label' => __( 'Member Name', 'elementor-webtheme' ),
					'type' => Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'name_bottom_space',
				[
					'label' => __( 'Name Spacing', 'elementor-webtheme' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .team-slide .team-slide-member-name h1' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'name_color',
				[
					'label' => __( 'Name Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .team-slide .team-slide-member-name h1' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'name_typography',
					'selector' => '{{WRAPPER}} .team-slide .team-slide-member-name h1, {{WRAPPER}} .elementor-icon-box-content .elementor-icon-box-name a',
				]
			);
			$this->add_control(
				'heading_designation',
				[
					'label' => __( 'Member Designation', 'elementor-webtheme' ),
					'type' => Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
			$this->add_control(
				'designation_color',
				[
					'label' => __( 'Designation Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .team-slide-member-designation p' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'designation_typography',
					'selector' => '{{WRAPPER}} .team-slide-member-designation p',
				]
			);
		$this->end_controls_section();
		
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slides = isset($settings['slides']) ? $settings['slides'] : '';
		$this->add_render_attribute( 'member_name_text', 'class', 'team-slide-member-name' );
		$this->add_render_attribute( 'member_designation_text', 'class', 'team-slide-member-designation' );
		?>
		<?php if($settings['select_option']=='one'){ ?>
		<div class="team-slide owl-carousel owl-loaded">
			<?php foreach ($slides as $slide) { 
			?>
				<div class="team-slide-section">
					<div class="team-slide-member-image">
						<img src="<?php echo $slide['select_img']['url'] ?>" alt="">
						<ul class="team-slide-media-icon">
                            <?php foreach (  $settings['list'] as $item ) { ?>
                                <li><a href="<?php echo esc_url($item['social_link']['url']); ?>"><?php \Elementor\Icons_Manager::render_icon( $item['social_media_icon'], [ 'aria-hidden' => 'true' ] ); ?></a></li>
                            <?php } ?>
                        </ul>
					</div>
					<div class="team-slide-content">
						<div class="team-slide-member-designation">
							<p><?php echo $slide['member_designation_text']; ?></p>
						</div>
						<div class="team-slide-member-name">
							<h1><?php echo $slide['member_name_text']; ?></h1>
						</div>
					</div>
				</div>
			<?php } ?>
		</div>
		<script>
			jQuery(document).ready(function($) {
				"use strict";
				$('.team-slide').owlCarousel({
					dots: true,
					nav: false,
					autoplay:true,
					margin:30,
					autoplayTimeout: 10000,
					navText: ["<i class='fa fa-long-arrow-left'></i>", "<i class='fa fa-long-arrow-right''></i>"],
					responsive: {
						0: {
							items: 1
						},
						768: {
							items: 2
						},
						1025: {
							items: 3
						},
						1920: {
							items: 3
						}
					}
				})	
			});
		</script>
		<?php }?>
		<?php
	}
}