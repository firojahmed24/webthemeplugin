<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Typography;
use Elementor\Scheme_Typography;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Repeater;
use Elementor\Group_Control_Box_Shadow;
if(!defined('ABSPATH')) exit;
class CallToAction extends Widget_Base{
	public function get_name(){
		return "calltoaction";
	}
	public function get_title(){
		return "Call To Action";
	}
	public function get_icon(){
		return "eicon-image-rollover";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls() {
		$this->start_controls_section(
			'content_section',
			[
				'label' => __( 'Call To Action Content', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);
			$this->add_control(
				'video_url',
				[
					'label' => __( 'Video URL', 'elementor-webtheme' ),
					'type' => Controls_Manager::URL,
					'label_block' => true,
                    'default' => [
                        'url' => '#'
                    ]
				]
			);
			$this->add_control(
				'video_icon',
				[
					'label' => __( 'Video Icon', 'elementor-webtheme' ),
					'type' => Controls_Manager::ICONS,
					'default' => [
						'value' => 'fas fa-play',
					],
				]
			);
			$this->add_control(
				'subtitle',
				[
					'label' => __( 'Sub Title', 'elementor-webtheme' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Call  Sub Title', 'elementor-webtheme' ),
					'placeholder' => __( 'Enter Sub Title here', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'title',
				[
					'label' => __( 'Title', 'elementor-webtheme' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'Main  Title', 'elementor-webtheme' ),
					'placeholder' => __( 'Enter Title here', 'elementor-webtheme' ),
					'label_block' => true,
				]
			);
			$this->add_control(
				'description',
				[
					'label' => __( 'Description', 'elementor-webtheme' ),
					'type' => Controls_Manager::TEXTAREA,
					'default' => __( 'Call to action Description', 'elementor-webtheme' ),
					'placeholder' => __( 'Entyer Description here', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'button-text',
				[
					'label' => __( 'Button Text', 'elementor-webtheme' ),
					'type' => Controls_Manager::TEXT,
					'default' => __( 'See More', 'elementor-webtheme' ),
					'placeholder' => __( 'Enter Button text', 'elementor-webtheme' ),
				]
			);
			$this->add_control(
				'button_url',
				[
					'label' => __( 'Link', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::URL,
					'placeholder' => __( 'https://your-link.com', 'elementor-webtheme' ),
					'show_external' => true,
					'default' => [
						'url' => '',
						'is_external' => true,
						'nofollow' => true,
					],
				]
			);
		$this->end_controls_section();

/* ------------------     Style  coding start here         ------------------------*/

		$this->start_controls_section(
			'section_option',
			[
				'label' => __( 'Call Action Option', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'select_option',
				[
					'label' => __( 'Choose Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
					],
					'default' => 'one',
					
				]
			);
			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .single-call-to-action' => 'text-align: {{VALUE}};',
					],
					// 'condition' => [
					// 	'select_style' => 'two',
					// ]
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'color_section',
			[
				'label' => __( 'Text CSS', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'subtitle-color',
			[
				'label' => __( 'Sub Title Color', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'default' => '',
				'separator' => 'before',
				'selectors' => [
					'{{WRAPPER}} .call-action-title h3' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typography',
				'label' => __( 'Sub Title Typography', 'elementor-webtheme' ),
				'selector' => '{{WRAPPER}} .call-action-title h3',
			]
		);
			$this->add_control(
				'title-color',
				[
					'label' => __( 'Title Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .call-action-title h1' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'label' => __( 'Title Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .call-action-title h1',
				]
			);
			
			$this->add_control(
				'description-color',
				[
					'label' => __( 'Description Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'separator' => 'before',
					'selectors' => [
						'{{WRAPPER}} .call-action-description p' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'label' => __( 'Description Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .call-action-description p',
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'button_section',
			[
				'label' => __( 'Button CSS', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->start_controls_tabs('style_tabs');
			$this->start_controls_tab(
				'style_normal_tab',
				[
					'label' => __( 'Normal', 'elementor-webtheme' ),
				]
			);
				$this->add_control(
					'button_text_color',
					[
						'label' => __( 'Button Text Color', 'elementor-webtheme' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .call-action-button a' => 'color: {{VALUE}};',
						],
					]
				);
				$this->add_control(
					'button-color',
					[
						'label' => __( 'Button BG Color', 'elementor-webtheme' ),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .call-action-button a' => 'background: {{VALUE}};',
						],
					]
				);
			$this->end_controls_tab();
			$this->start_controls_tab(
				'style_hover_tab',
				[
					'label' => __( 'Hover', 'elementor-webtheme' ),
				]
			);
				$this->add_control(
					'hover_button_text_color',
					[
						'label' => __( 'Text Color', 'elementor-webtheme' ),
						'type' => \Elementor\Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .call-action-button a:hover' => 'color: {{VALUE}};',
						],
					]
				);
				$this->add_control(
					'button-hover-color',
					[
						'label' => __( 'Button Color', 'elementor-webtheme' ),
						'type' => Controls_Manager::COLOR,
						'default' => '',
						'selectors' => [
							'{{WRAPPER}} .call-action-button a:hover' => 'background: {{VALUE}};',
						],
					]
				);
			$this->end_controls_tab();
			$this->end_controls_tabs();

			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'name' => 'button_typography',
					'label' => __( 'Typography', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .call-action-button a',
				]
			);
		$this->end_controls_section();
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$this->add_render_attribute( 'i', 'class', $settings['video_icon'] );
		?>
		<?php if($settings['select_option']=='one'){ ?>
			<div class="single-call-to-action">
				<div class="call-video-button">
					<?php if( !empty( $settings['video_url']['url'] ) ){ ?>
						<div class="call-video-link">
							<a data-vbtype="youtube" data-autoplay="true" href="<?php echo esc_url($settings['video_url']['url']); ?>"><i <?php echo $this->get_render_attribute_string( 'i' ); ?>></i></a>

						</div>
					<?php } ?>
				</div>
				<div class="call-action-content">
					<div class="call-action-title">
						<h3><?php echo $settings['subtitle']; ?></h3>
						<h1><?php echo $settings['title']; ?></h1>
					</div>		
					<div class="call-action-description">
						<p><?php echo $settings['description']; ?></p>
					</div>						
					<?php if( !empty($settings['button-text']) ){ ?>
					<div class="call-action-button">
						<a href="<?php echo esc_url($settings['button_url']['url']); ?>"><?php echo $settings['button-text']; ?></a>
					</div>
					<?php } ?>
				</div>
			</div>
		<?php }elseif($settings['select_option']=='two'){ ?>
			<div class="single-call-to-action option2">
				<div class="row align-items-center">
					<div class="col-md-8">
						<div class="single-call-to-action">
							<div class="call-action-content">
								<div class="call-action-title">
									<h3><?php echo $settings['subtitle']; ?></h3>
									<h1><?php echo $settings['title']; ?></h1>
								</div>		
								<div class="call-action-description">
									<p><?php echo $settings['description']; ?></p>
								</div>						
								<?php if( !empty($settings['button-text']) ){ ?>
								<div class="call-action-button">
									<a href="<?php echo esc_url($settings['button_url']['url']); ?>"><?php echo $settings['button-text']; ?></a>
								</div>
								<?php } ?>
							</div>
						</div>
					</div>
					<div class="col-md-4 align-items-center">
						<div class="call-video-button">
							<?php if( !empty( $settings['video_url']['url'] ) ){ ?>
								<div class="call-video-link">
									<a data-vbtype="youtube" data-autoplay="true" href="<?php echo esc_url($settings['video_url']['url']); ?>"><i <?php echo $this->get_render_attribute_string( 'i' ); ?>></i></a>
								</div>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		<?php } ?>
		<?php
	}
}