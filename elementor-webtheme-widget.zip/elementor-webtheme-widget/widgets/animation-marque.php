<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if(!defined('ABSPATH')) exit;
class AnimationMarque extends Widget_Base{
	public function get_name(){
		return "AnimationMarque";
	}
	public function get_title(){
		return "Animation Marque";
	}
	public function get_icon(){
		return "eicon-font";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
		$this->start_controls_section(
			'text_section',
			[
				'label' => esc_html__( 'Text', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title_text',
			[
				'label' => __( 'Title 1', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title 1', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( 'This is title 1', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
				'single_image',
				[
				    'label' => esc_html__('Image','elementor-webtheme'),
				    'type'=> \Elementor\Controls_Manager::MEDIA,
				    'default' => [
					  'url' => \Elementor\Utils::get_placeholder_image_src(),
				    ],
				]
			);
		$this->add_control(
			'title_text2',
			[
				'label' => __( 'Title Two', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title 2', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( 'This is the title 2', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'title_text3',
			[
				'label' => __( 'Title 3', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title 3', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( 'This is the title 3', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'title_text4',
			[
				'label' => __( 'Title 4', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title 4', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( 'This is the title 4', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'title_text5',
			[
				'label' => __( 'Title 5', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title 5', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( 'This is the title 5', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'title_text6',
			[
				'label' => __( 'Title 6', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your Title 6', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( 'This is the title 6', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'title_text7',
			[
				'label' => __( 'Title 7', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title 7', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( 'This is the title 7', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'title_text8',
			[
				'label' => __( 'Title 8', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title 8', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( 'This is the title 8', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'title_text9',
			[
				'label' => __( 'Title 9', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title 9', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( 'This is the title 9', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'title_text10',
			[
				'label' => __( 'Title 10', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'dynamic' => [
					'active' => true,
				],
				'placeholder' => __( 'Enter your title 10', 'elementor-webtheme' ),
				'label_block' => true,
				'default' => __( 'This is the title 10', 'elementor-webtheme' ),
			]
		);
		$this->end_controls_section();


/*
==========
Style Tab
==========
*/

		$this->start_controls_section(
			'style_section',
			[
				'label' => __( 'Choose Option', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'select_option',
			[
				'label' => __( 'Choose Option', 'elementor-webtheme' ),
				'type' => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'one' => __( 'One', 'elementor-webtheme' ),
					'two' => __( 'Two', 'elementor-webtheme' ),
				],
				'default' => 'one',
				
			]
		);
		$this->end_controls_section();
		
		$this->start_controls_section(
			'title_section_option',
			[
				'label' => __( 'Title css', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .marque-section .marque-content h1' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .marque-section .marque-content h1, {{WRAPPER}}',
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .marque-section .marque-content h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
	}
	protected function render(){
		$settings = $this->get_settings_for_display();
		?>
			<?php if($settings['select_option']=='one'){ ?>
			<div class="marque-section option1">
					<div class="marque-content">
						<div class="marque-text-animate">
							<h1> <img src="<?php echo $settings['single_image']['url']; ?>"> <?php echo $settings['title_text'];?></h1>
							<h1> <img src="<?php echo $settings['single_image']['url']; ?>"> <?php echo $settings['title_text2'];?></h1>
							<h1><img src="<?php echo $settings['single_image']['url']; ?>"> <?php echo $settings['title_text3'];?></h1>
							<h1><img src="<?php echo $settings['single_image']['url']; ?>"> <?php echo $settings['title_text4'];?></h1>
							<h1><img src="<?php echo $settings['single_image']['url']; ?>"> <?php echo $settings['title_text5'];?></h1>
						</div>
					</div>
					<div class="marque-content">
						<div class="marque-text-animate">
							<h1><img src="<?php echo $settings['single_image']['url']; ?>"> <?php echo $settings['title_text6'];?></h1>
							<h1><img src="<?php echo $settings['single_image']['url']; ?>"> <?php echo $settings['title_text7'];?></h1>
							<h1><img src="<?php echo $settings['single_image']['url']; ?>"> <?php echo $settings['title_text8'];?></h1>
							<h1><img src="<?php echo $settings['single_image']['url']; ?>"> <?php echo $settings['title_text9'];?></h1>
							<h1><img src="<?php echo $settings['single_image']['url']; ?>"> <?php echo $settings['title_text10'];?></h1>
						</div>
					</div>
				</div>
			<?php } elseif($settings['select_option']=='two'){ ?>
			<div class="marque-section option2">
					<div class="marque-content">
						<div class="marque-text-animate">
							<h1><?php echo $settings['title_text'];?></h1>
							<h1 class="title-two"><?php echo $settings['title_text2'];?></h1>
							<h1><?php echo $settings['title_text3'];?></h1>
							<h1 class="title-two"><?php echo $settings['title_text4'];?></h1>
						</div>
					</div>
					<div class="marque-content">
						<div class="marque-text-animate">
							<h1><?php echo $settings['title_text6'];?></h1>
							<h1 class="title-two"><?php echo $settings['title_text7'];?></h1>
							<h1><?php echo $settings['title_text8'];?></h1>
							<h1 class="title-two"><?php echo $settings['title_text9'];?></h1>
						</div>
					</div>
				</div>
			<?php }?>
		<?php
	}
}