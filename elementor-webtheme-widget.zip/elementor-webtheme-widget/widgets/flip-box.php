<?php
if(!defined('ABSPATH')) exit;
class FlipBoxSection extends \Elementor\Widget_Base{
	public function get_name(){
		return "flipbox";
	}
	public function get_title(){
		return "Flip Box Section";
	}
	public function get_icon(){
		return "eicon-flip-box";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
    protected function register_controls(){
        $this->start_controls_section(
            'above_part',
            [
                'label' => esc_html__( 'Above Part', 'elementor-webtheme' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );
            $this->add_control(
                'above_icon_type',
                [
                    'label' => esc_html__( 'Icon Type', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::CHOOSE,
                    'label_block' => false,
                    'default' => 'icon',
                    'options' => [
                        'none' => [
                            'title' => esc_html__( 'None', 'elementor-webtheme' ),
                            'icon' => 'eicon-close',
                        ],
                        'icon' => [
                            'title' => esc_html__( 'Icon', 'elementor-webtheme' ),
                            'icon' => 'eicon-star',
                        ],
                        'image' => [
                            'title' => esc_html__( 'Image', 'elementor-webtheme' ),
                            'icon' => 'eicon-image',
                        ],
                    ],
                    'toggle' => false,
                ]
            );

            $this->add_control(
                'above_icon',
                [
                    'label' => esc_html__( 'Icon', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'condition' => [
                      'above_icon_type' => 'icon'
                    ],
                ]
            );

            $this->add_control(
                'above_image',
                [
                    'label' => esc_html__( 'Image', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                    'condition' => [
                        'above_icon_type' => 'image'
                    ]
                ]
            );

            $this->add_control(
                'above_title',
                [
                    'label' => __( 'Above Title', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => __('Above Title', 'elementor-webtheme' ),
                    'separator' => 'before', 
                    'label_block' => true,
                    'placeholder' => __( 'Enter Above title', 'elementor-webtheme' ),
                ]
            );
            $this->add_control(
                'above_description',
                [
                    'label' => __( 'Above Description', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'placeholder' => __( 'Enter Above Text', 'elementor-webtheme' ),
                    'default' => __( 'Above Description', 'elementor-webtheme' ),
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'behind_part',
            [
                'label' => esc_html__( 'Behind Part', 'elementor-webtheme' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

            $this->add_control(
                'behind_icon_type',
                [
                    'label' => esc_html__( 'Icon Type', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::CHOOSE,
                    'label_block' => false,
                    'default' => 'icon',
                    'options' => [
                        'none' => [
                            'title' => esc_html__( 'None', 'elementor-webtheme' ),
                            'icon' => 'eicon-close',
                        ],
                        'icon' => [
                            'title' => esc_html__( 'Icon', 'elementor-webtheme' ),
                            'icon' => 'eicon-star',
                        ],
                        'image' => [
                            'title' => esc_html__( 'Image', 'elementor-webtheme' ),
                            'icon' => 'eicon-image',
                        ],
                    ],
                    'toggle' => false,
                ]
            );

            $this->add_control(
                'behind_icon',
                [
                    'label' => esc_html__( 'Behind Icon', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                    'condition' => [
                      'behind_icon_type' => 'icon'
                    ],
                ]
            );

            $this->add_control(
                'behind_image',
                [
                    'label' => esc_html__( 'Behind Image', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::MEDIA,
                    'default' => [
                        'url' => \Elementor\Utils::get_placeholder_image_src(),
                    ],
                    'condition' => [
                        'behind_icon_type' => 'image'
                    ]
                ]
            );

            $this->add_control(
                'behind_title',
                [
                    'label' => __( 'Behind Title', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'label_block' => true,
                    'default' => __('Behind Title', 'elementor-webtheme' ),
                    'placeholder' => __( 'Enter Behind title', 'elementor-webtheme' ),
                    'separator' => 'before', 
                ]
            );

            $this->add_control(
                'behind_description',
                [
                    'label' => __( 'Behind Description', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXTAREA,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'default' => __('Behind Description', 'elementor-webtheme' ),
                ]
            );

            $this->add_control(
                'behind_btn_heading',
                [
                    'label' => esc_html__( 'Behind Button', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'separator' => 'before',
                ]
            );
            $this->add_control(
                'behind_btn_text',
                [
                    'label' => __( 'Behind Text', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'dynamic' => [
                        'active' => true,
                    ],
                    'placeholder' => __( 'Read More', 'elementor-webtheme' ),
                    'label_block' => true,
                    'default' => __( 'Read More', 'elementor-webtheme' ),
                ]
            );
            $this->add_control(
                'behind_btn_link',
                [
                    'label' => __( 'Link', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::URL,
                    'placeholder' => __( 'https://your-link.com', 'elementor-webtheme' ),
                ]
            );
            $this->add_control(
                'behind_btn_icon',
                [
                    'label' => __( 'Behind Icon', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::ICONS,
                ]
            );

        $this->end_controls_section(); 

/*---------  flip box css style start here  --------*/
        $this->start_controls_section(
            'section_option',
            [
                'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'select_option',
                [
                    'label' => __( 'Select Your Option', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'options' => [
                        'one' => __( 'One', 'elementor-webtheme' ),
                        'two' => __( 'Two', 'elementor-webtheme' ),
                    ],
                    'default' => 'one',
                    
                ]
            );
            $this->add_responsive_control(
                'flip_box_height',
                [
                    'label' => esc_html__( 'Height', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => ['px'],
                    'range' => [
                        'px' => [
                            'min' => 100,
                            'max' => 1000,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .flip-box' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'flip_box_above_style',
            [
                'label' => esc_html__( 'Above Part CSS', 'elementor-webtheme' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_group_control(
                \Elementor\Group_Control_background::get_type(),
                [
                    'name' => 'font_background',
                    'label' => __( 'background', 'elementor-webtheme' ),
                    'types' => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-above',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'above_border',
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-above',
                ]
            );

            $this->add_control(
                'above_border_radius',
                [
                    'label' => esc_html__( 'Border Radius', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'above_box_shadow',
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-above',
                ]
            );

            $this->add_control(
                'above_icon_style',
                [
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'label' => esc_html__( 'Icon CSS', 'elementor-webtheme' ),
                    'separator' => 'before',
                    'condition' => [
                      'above_icon_type' => 'icon'
                    ],
                ]
            );

            $this->add_control(
                'above_icon_color',
                [
                    'label' => __( 'Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above .flip-icon i' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                'above_icon_background_color',
                [
                    'label' => __( 'background Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above .flip-icon i' => 'background: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'above_icon_typography',
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-above .flip-icon i',
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'above_icon_border',
                    'label' => __( 'Border', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-above .flip-icon i',
                ]
            );
            $this->add_responsive_control(
                'above_icon_border_radius',
                [
                    'label' => __( 'Border Radius', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above .flip-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'above_icon_margin',
                [
                    'label' => __( 'Margin', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above .flip-icon i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_control(
                'above_icon_height',
                [
                    'label' => __( 'Height', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above .flip-icon i' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_control(
                'above_icon_width',
                [
                    'label' => __( 'Width', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above .flip-icon i' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            

            $this->add_control(
                'above_title_style',
                [
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'label' => esc_html__( 'Title CSS', 'elementor-webtheme' ),
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'above_title_color',
                [
                    'label' => esc_html__( 'Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above .above-title h1' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'above_title_typography',
                    'label' => esc_html__( 'Typography', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-above .above-title h1',
                ]
            );

            $this->add_responsive_control(
                'above_title_margin',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Margin', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above .above-title h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'above_description_style',
                [
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'label' => esc_html__( 'Description CSS', 'elementor-webtheme' ),
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'above_description_color',
                [
                    'label' => esc_html__( 'Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above .above-description' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'above_description_typography',
                    'label' => esc_html__( 'Typography', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-above .above-description',
                ]
            );

            $this->add_responsive_control(
                'above_description_margin',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Margin', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-above .above-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();

        $this->start_controls_section(
            'flip_box_behind_style',
            [
                'label' => esc_html__( 'Behind Part CSS', 'elementor-webtheme' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

            $this->add_group_control(
                \Elementor\Group_Control_background::get_type(),
                [
                    'name' => 'behind_background',
                    'label' => __( 'background', 'elementor-webtheme' ),
                    'types' => [ 'classic', 'gradient', 'video' ],
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'behind_border',
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind',
                ]
            );

            $this->add_control(
                'behind_border_radius',
                [
                    'label' => esc_html__( 'Border Radius', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'behind_box_shadow',
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind',
                ]
            );

            $this->add_control(
                'behind_icon_style',
                [
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'label' => esc_html__( 'Icon CSS', 'elementor-webtheme' ),
                    'separator' => 'before',
                    'condition' => [
                      'above_icon_type' => 'icon'
                    ],
                ]
            );

            $this->add_control(
                'behind_icon_color',
                [
                    'label' => __( 'Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .flip-icon i' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_control(
                'behind_icon_background_color',
                [
                    'label' => __( 'background Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'default' => '',
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .flip-icon i' => 'background: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'behind_icon_border',
                    'label' => __( 'Border', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind .flip-icon i',
                ]
            );
            $this->add_responsive_control(
                'behind_icon_border_radius',
                [
                    'label' => __( 'Border Radius', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .flip-icon i' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_responsive_control(
                'behind_icon_margin',
                [
                    'label' => __( 'Margin', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .flip-icon i' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_control(
                'behind_icon_height',
                [
                    'label' => __( 'Height', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .flip-icon i' => 'height: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_control(
                'behind_icon_width',
                [
                    'label' => __( 'Width', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SLIDER,
                    'size_units' => [ 'px', '%' ],
                    'range' => [
                        'px' => [
                            'min' => 0,
                            'max' => 1000,
                            'step' => 5,
                        ],
                        '%' => [
                            'min' => 0,
                            'max' => 100,
                        ],
                    ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .flip-icon i' => 'width: {{SIZE}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'behind_icon_typography',
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind .flip-icon i',
                ]
            );

            $this->add_control(
                'behind_title_style',
                [
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'label' => esc_html__( 'Title CSS', 'elementor-webtheme' ),
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'behind_title_color',
                [
                    'label' => esc_html__( 'Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-title h1' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'behind_title_typography',
                    'label' => esc_html__( 'Typography', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-title h1',
                ]
            );

            $this->add_responsive_control(
                'behind_title_margin',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Margin', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-title h1' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'behind_description_style',
                [
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'label' => esc_html__( 'Description CSS', 'elementor-webtheme' ),
                    'separator' => 'before',
                ]
            );

            $this->add_control(
                'behind_description_color',
                [
                    'label' => esc_html__( 'Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-description p' => 'color: {{VALUE}};',
                    ],
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'behind_description_typography',
                    'label' => esc_html__( 'Typography', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-description p',
                ]
            );

            $this->add_responsive_control(
                'behind_description_margin',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Margin', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-description' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

            $this->add_control(
                'behind_btn_style',
                [
                    'type' => \Elementor\Controls_Manager::HEADING,
                    'label' => esc_html__( 'Button CSS', 'elementor-webtheme' ),
                    'separator' => 'before',
                ]
            );

            $this->add_group_control(
                \Elementor\Group_Control_Typography::get_type(),
                [
                    'name' => 'behind_btn_typography',
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-btn',
                ]
            );

            $this->start_controls_tabs(
                'style_tabs'
            );

            $this->start_controls_tab(
                'style_normal_tab',
                [
                    'label' => esc_html__( 'Normal', 'elementor-webtheme' ),
                ]
            );

            $this->add_control(
                'behind_btn_text_color',
                [
                    'label' => esc_html__( 'Text Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-btn' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_background::get_type(),
                [
                    'name' => 'behind_btn_background',
                    'label' => esc_html__( 'background', 'elementor-webtheme' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-btn',
                ]
            );

            $this->end_controls_tab();

            $this->start_controls_tab(
                'style_hover_tab',
                [
                    'label' => esc_html__( 'Hover', 'elementor-webtheme' ),
                ]
            );

            $this->add_control(
                'behind_btn_text_hover_color',
                [
                    'label' => esc_html__( 'Text Color', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-btn:hover' => 'color: {{VALUE}}',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_background::get_type(),
                [
                    'name' => 'behind_btn_hover_background',
                    'label' => esc_html__( 'background', 'elementor-webtheme' ),
                    'types' => [ 'classic', 'gradient' ],
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-btn:hover',
                ]
            );

            $this->end_controls_tab();

            $this->end_controls_tabs();

            $this->add_group_control(
                \Elementor\Group_Control_Border::get_type(),
                [
                    'name' => 'behind_btn_border',
                    'label' => esc_html__( 'Border', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-btn',
                    'separator' => 'before',
                ]
            );
            $this->add_responsive_control(
                'behind_btn_border_radius',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Border Radius', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );
            $this->add_group_control(
                \Elementor\Group_Control_Box_Shadow::get_type(),
                [
                    'name' => 'behind_btn_box_shadow',
                    'label' => esc_html__( 'Box Shadow', 'elementor-webtheme' ),
                    'selector' => '{{WRAPPER}} .single-flip-box .flip-box-behind .behind-btn',
                ]
            );
            $this->add_responsive_control(
                'behind_btn_padding',
                [
                    'type' => \Elementor\Controls_Manager::DIMENSIONS,
                    'label' => esc_html__( 'Padding', 'elementor-webtheme' ),
                    'size_units' => [ 'px', 'em', '%' ],
                    'selectors' => [
                        '{{WRAPPER}} .single-flip-box.flip-box-behind .behind-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    ],
                ]
            );

        $this->end_controls_section();
    }

    protected function render() {

        $settings = $this->get_settings_for_display();
        
        ?>

        <?php if($settings['select_option']=='one'){ ?>

        <div class="single-flip-box option1">
            <div class="flip-box-content">
                <div class="flip-box-above">
                    <div class="flip-content">
                        <div class="flip-icon">
                            <?php if( !empty($settings['above_icon']) ) { ?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['above_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php }elseif( !empty($settings['above_image']['url']) ){ ?>
                                <img src="<?php echo $settings['above_image']['url']; ?>" alt="">
                            <?php } ?>
                        </div>
                        <?php if( !empty($settings['above_title']) ) { ?>
                            <div class="above-title">
                                <h1><?php echo $settings['above_title']; ?></h1>
                            </div>
                        <?php } ?>

                        <?php if( !empty($settings['above_description']) ) { ?>
                            <div class="above-description">
                                 <p><?php echo esc_attr($settings['above_description']);?></p>
                            </div>
                        <?php } ?>
                    </div>
                </div>
                <div class="flip-box-behind">
                    <div class="flip-content">
                        <div class="icon">
                            <?php if( !empty($settings['behind_icon']) ) { ?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['behind_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            <?php }elseif( !empty($settings['behind_image']['url']) ){ ?>
                                <img src="<?php echo $settings['behind_image']['url']; ?>" alt="">
                            <?php } ?>
                        </div>
                        <?php if( !empty($settings['behind_title']) ) { ?>
                            <div class="behind-title">
                                <h1><?php echo esc_attr($settings['behind_title']);?></h1>
                            </div>
                        <?php } ?>

                        <?php if( !empty($settings['behind_description']) ) { ?>
                            <div class="behind-description">
                                <p><?php echo esc_attr($settings['behind_description']);?></p>
                            </div>
                        <?php } ?>

                        <?php if( !empty($settings['behind_btn_text']) ) { ?>
                        <a class="behind-btn" href="<?php echo esc_url($settings['behind_btn_link']['url']);?>">
                            <?php echo $settings['behind_btn_text'];?>
                            <?php \Elementor\Icons_Manager::render_icon( $settings['behind_btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                        </a>
                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>

        <?php }elseif($settings['select_option']=='two'){ ?>

            <div class="single-flip-box option2">
                <div class="flip-box-content">
                    <div class="flip-box-above">
                        <div class="flip-content">
                            <div class="flip-icon">
                                <?php if( !empty($settings['above_icon']) ) { ?>
                                    <?php \Elementor\Icons_Manager::render_icon( $settings['above_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php }elseif( !empty($settings['above_image']['url']) ){ ?>
                                    <img src="<?php echo $settings['above_image']['url']; ?>" alt="">
                                <?php } ?>
                            </div>
                            <?php if( !empty($settings['above_title']) ) { ?>
                                <div class="above-title">
                                    <h1><?php echo $settings['above_title']; ?></h1>
                                </div>
                            <?php } ?>

                            <?php if( !empty($settings['above_description']) ) { ?>
                                <div class="above-description">
                                    <p><?php echo esc_attr($settings['above_description']);?></p>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="flip-box-behind">
                        <div class="flip-content">
                            <div class="icon">
                                <?php if( !empty($settings['behind_icon']) ) { ?>
                                    <?php \Elementor\Icons_Manager::render_icon( $settings['behind_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                <?php }elseif( !empty($settings['behind_image']['url']) ){ ?>
                                    <img src="<?php echo $settings['behind_image']['url']; ?>" alt="">
                                <?php } ?>
                            </div>
                            <?php if( !empty($settings['behind_title']) ) { ?>
                                <div class="behind-title">
                                    <h1><?php echo esc_attr($settings['behind_title']);?></h1>
                                </div>
                            <?php } ?>

                            <?php if( !empty($settings['behind_description']) ) { ?>
                                <div class="behind-description">
                                    <p><?php echo esc_attr($settings['behind_description']);?></p>
                                </div>
                            <?php } ?>

                            <?php if( !empty($settings['behind_btn_text']) ) { ?>
                            <a class="behind-btn" href="<?php echo esc_url($settings['behind_btn_link']['url']);?>">
                                <?php echo $settings['behind_btn_text'];?>
                                <?php \Elementor\Icons_Manager::render_icon( $settings['behind_btn_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                            </a>
                            <?php } ?>
                        </div>
                    </div>
                </div>
            </div>
            
            <?php } ?>
        <?php
    }
}