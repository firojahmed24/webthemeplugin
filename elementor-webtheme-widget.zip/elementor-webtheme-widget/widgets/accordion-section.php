<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
if(!defined('ABSPATH')) exit;
class AccordionSection extends Widget_Base{
	public function get_name(){
		return "accordionsection";
	}
	public function get_title(){
		return "Accordion / Faq";
	}
	public function get_icon(){
		return "eicon-accordion";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
		$this->start_controls_section(
			'title_section',
				[
					'label' => __( 'Faq Text', 'elementor-webtheme' ),
					'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
				]
			);
			$repeater = new \Elementor\Repeater();

			$repeater->add_control(
				'icon_image',
				[
					'label' => __( 'Icon Image', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::MEDIA,
				]
			);
			$repeater->add_control(
				'title_text',
				[
					'label' => __( 'Faq Title', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXT,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter Faq title', 'elementor-webtheme' ),
					'label_block' => true,
					'default' => __( 'This is faq title', 'elementor-webtheme' ),
				]
			);
			$repeater->add_control(
				'description_text',
				[
					'label' => __( 'Description', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::TEXTAREA,
					'dynamic' => [
						'active' => true,
					],
					'placeholder' => __( 'Enter faq paragraph', 'elementor-webtheme' ),
					'default' => __( 'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'elementor-webtheme' ),
				]
			);

			$this->add_control(
				'faq_list',
				[
					'label' => __( 'Faq Lists', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::REPEATER,
					'fields' => $repeater->get_controls(),
					'default' => [
						[
							'title_text' => __( 'Faq Title One', 'elementor-webtheme' ),
							'description_text' => __( 'This faq descriptipn text.You can change this text.', 'elementor-webtheme' ),
						],
						[
							'title_text' => __( 'Faq Title Two', 'elementor-webtheme' ),
							'description_text' => __( 'This faq descriptipn text.You can change this text.', 'elementor-webtheme' ),
						],
					],
					'title_field' => '{{{ title_text }}}',
				]
			);

		$this->end_controls_section();


/*     ==========    Style Tab Start here           ==========*/

		$this->start_controls_section(
			'section_option',
			[
				'label' => __( 'Fac Options', 'elementor-webtheme' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'select_option',
				[
					'label' => __( 'Choose Option', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::SELECT,
					'options' => [
						'one' => __( 'One', 'elementor-webtheme' ),
						'two' => __( 'Two', 'elementor-webtheme' ),
					],
					'default' => 'one',
					
				]
			);
			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .faq-box' => 'text-align: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'title_section_style',
			[
				'label' => __( 'Title', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'title_color',
				[
					'label' => __( 'Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .faq-box .accordion' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .faq-box .accordion, {{WRAPPER}} .elementor-icon-box-content .elementor-icon-box-title a',
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name' => 'border',
					'label' => __( 'Border', 'elementor-webtheme' ),
					'selector' => '{{WRAPPER}} .faq-box .accordion',
				]
			);
			$this->add_responsive_control(
				'title_margin',
				[
					'label' => __( 'Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .faq-box .accordion' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();

		$this->start_controls_section(
			'description_section_style',
			[
				'label' => __( 'Description', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

			$this->add_control(
				'description_color',
				[
					'label' => __( 'Color', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .faq-box .panel p' => 'color: {{VALUE}};',
					],
				]
			);

			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'selector' => '{{WRAPPER}} .faq-box .panel p',
				]
			);
			$this->add_responsive_control(
				'description_margin',
				[
					'label' => __( 'Margin', 'elementor-webtheme' ),
					'type' => \Elementor\Controls_Manager::DIMENSIONS,
					'size_units' => [ 'px', 'em', '%' ],
					'selectors' => [
						'{{WRAPPER}} .faq-box .panel p' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();
	}
	/* Start Faq section here  */
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>
		<?php if($settings['select_option']=='one'){ ?>
			<div class="accordion-single">
				<ul class="accordion-content">
					<?php foreach (  $settings['faq_list'] as $item ) { ?>
					<li>
						<a><img src="<?php echo $item['icon_image']['url']; ?>" alt=""><?php echo $item['title_text']; ?></a>
						<p><?php echo $item['description_text']; ?></p>
					</li>
					<?php } ?>
				</ul>
			</div>
            <script>
            	jQuery(document).ready(function($) {
            	"use strict";
					$('.accordion-content > li:eq(0) a').addClass('active').next().slideDown();
					$('.accordion-content a').click(function() {
						var dropDown = $(this).closest('li').find('p');
			
						$(this).closest('.accordion-content').find('p').not(dropDown).slideUp();
			
						if ($(this).hasClass('active')) {
							$(this).removeClass('active');
						} else {
							$(this).closest('.accordion-content').find('a.active').removeClass('active');
							$(this).addClass('active');
						}
						dropDown.stop(false, true).slideToggle();
					});
            	});
            </script>	
		<?php }elseif($settings['select_option']=='two'){ ?>
				<div class="accordion-single option2">
					<ul class="accordion-content">
						<?php foreach (  $settings['faq_list'] as $item ) { ?>
						<li>
							<a><?php echo $item['title_text']; ?></a>
							<p><?php echo $item['description_text']; ?></p>
						</li>
						<?php } ?>
					</ul>
				</div>
            <script>
            	jQuery(document).ready(function($) {
            		"use strict";
					$('.accordion-content > li:eq(0) a').addClass('active').next().slideDown();
					$('.accordion-content a').click(function() {
						var dropDown = $(this).closest('li').find('p');
			
						$(this).closest('.accordion-content').find('p').not(dropDown).slideUp();
			
						if ($(this).hasClass('active')) {
							$(this).removeClass('active');
						} else {
							$(this).closest('.accordion-content').find('a.active').removeClass('active');
							$(this).addClass('active');
						}
						dropDown.stop(false, true).slideToggle();
					});
            	});
            </script>	
		<?php }
	}
}