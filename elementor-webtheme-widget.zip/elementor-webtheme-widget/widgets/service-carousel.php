<?php
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
if(!defined('ABSPATH')) exit;
class Servicecarousel extends Widget_Base{
	public function get_name(){
		return "servicecarousel";
	}
	public function get_title(){
		return "Service Carousel";
	}
	public function get_icon(){
		return "eicon-slides";
	}
	public function get_categories(){
		return ['elementor-webtheme-category'];
	}
	protected function register_controls(){
		$this->start_controls_section(
			'slider', [
				'label' => __( 'Service Slider', 'elementor-webtheme' ),
			]
		);
		$this->add_control(
			'slides', [
				'label' => __( 'Single Content', 'elementor-webtheme' ),
				'type' => Controls_Manager::REPEATER,
				'title_field' => '{{{title_text}}}',
				'fields' => [
					[
						'name' => 'select_img',
					    'label' => esc_html__('Single Image','tuchmocore'),
					    'type'=>Controls_Manager::MEDIA,
					    'default' => [
						  'url' => \Elementor\Utils::get_placeholder_image_src(),
					    ],
					],
					[
						'name' => 'icon',
						'label' => __( 'Service Icon', 'elementor-webtheme' ),
						'type' => Controls_Manager::ICONS,
					],
					[
						'name' => 'title_text',
						'label' => __( 'Service Title', 'elementor-webtheme' ),
						'type' => Controls_Manager::TEXT,
						'dynamic' => [
							'active' => true,
						],
						'placeholder' => __( 'Enter Service Title', 'elementor-webtheme' ),
						'label_block' => true,
						'default' => __( 'Service Title', 'elementor-webtheme' ),
					],
					[
						'name' => 'description_text',
						'label' => __( 'Service Description', 'elementor-webtheme' ),
						'type' => Controls_Manager::TEXTAREA,
						'dynamic' => [
							'active' => true,
						],
						'placeholder' => __( 'Enter Service Description', 'elementor-webtheme' ),
						'default' => __( 'Service Description. You can change service description.', 'elementor-webtheme' ),
					],
					[
						'name' => 'show_button',
						'label' => __( 'Show Button', 'elementor-webtheme' ),
						'type' => Controls_Manager::SWITCHER,
						'label_on' => __( 'Show', 'elementor-webtheme' ),
						'label_off' => __( 'Hide', 'elementor-webtheme' ),
						'return_value' => 'yes',
						'default' => 'yes',
					],
					[
						'name' => 'button_text',
						'label' => __( 'Button Text', 'elementor-webtheme' ),
						'type' => Controls_Manager::TEXT,
						'dynamic' => [
							'active' => true,
						],
						'placeholder' => __( 'Button text', 'elementor-webtheme' ),
						'label_block' => true,
						'default' => __( 'Read More', 'elementor-webtheme' ),
					],
					
					[
						'name' => 'button_icon',
						'label' => __( 'Button Icon', 'elementor-webtheme' ),
						'type' => Controls_Manager::ICONS,
						'default' => [
							'value' => 'fa fa-angle-right',
						],
					],
					[
						'name' => 'link',
						'label' => __( 'Button Link', 'elementor-webtheme' ),
						'type' => Controls_Manager::URL,
						'dynamic' => [
							'active' => true,
						],
						'placeholder' => __( 'https://your-link.com', 'elementor-webtheme' ),
						'separator' => 'before',
					],

				],
			]
		);
		$this->end_controls_section();

        /*---------  Service Carousel css style start here  --------*/

        $this->start_controls_section(
            'section_option',
            [
                'label' => esc_html__( 'Choose Option', 'elementor-webtheme' ),
                'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );
            $this->add_control(
                'select_option',
                [
                    'label' => __( 'Select Your Option', 'elementor-webtheme' ),
                    'type' => \Elementor\Controls_Manager::SELECT,
                    'options' => [
                        'one' => __( 'One', 'elementor-webtheme' ),
                        'two' => __( 'Two', 'elementor-webtheme' ),
                    ],
                    'default' => 'one',
                    
                ]
            );
		$this->end_controls_section();
		$this->start_controls_section(
			'icon_section_style',
			[
				'label' => __( 'Service Icon css', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs(
			'style_tabs'
		);
		$this->start_controls_tab(
			'style_normal_tab',
			[
				'label' => __( 'Normal', 'elementor-webtheme' ),
			]
		);
			$this->add_control(
				'icon_color',
				[
					'label' => __( 'Icon Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-box .service-box-icon i' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'background_color',
				[
					'label' => __( 'Icon BG Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-box .service-box-icon i' => 'background-color: {{VALUE}};',
					],
				]
			);
		$this->end_controls_tab();
		$this->start_controls_tab(
			'style_hover_tab',
			[
				'label' => __( 'Hover', 'elementor-webtheme' ),
			]
		);
			$this->add_control(
				'hover_icon_color',
				[
					'label' => __( 'Icon Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-box:hover .service-box-icon i' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'hover_background_color',
				[
					'label' => __( 'Icon BG Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-box:hover .service-box-icon i' => 'background-color: {{VALUE}};',
					],
				]
			);
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();
		$this->start_controls_section(
			'content_section_style',
			[
				'label' => __( 'Text css', 'elementor-webtheme' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_responsive_control(
				'text_align',
				[
					'label' => __( 'Alignment', 'elementor-webtheme' ),
					'type' => Controls_Manager::CHOOSE,
					'options' => [
						'left' => [
							'title' => __( 'Left', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-left',
						],
						'center' => [
							'title' => __( 'Center', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-center',
						],
						'right' => [
							'title' => __( 'Right', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-right',
						],
						'justify' => [
							'title' => __( 'Justified', 'elementor-webtheme' ),
							'icon' => 'eicon-text-align-justify',
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service-carousel-section' => 'text-align: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'heading_title',
				[
					'label' => __( 'Title css', 'elementor-webtheme' ),
					'type' => Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
			$this->add_responsive_control(
				'title_bottom_space',
				[
					'label' => __( 'Title Spacing', 'elementor-webtheme' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 100,
						],
					],
					'selectors' => [
						'{{WRAPPER}} .service-carousel-section .service-carousel-title a h1' => 'margin-bottom: {{SIZE}}{{UNIT}};',
					],
				]
			);
			$this->add_control(
				'title_color',
				[
					'label' => __( 'Title Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-carousel-section .service-carousel-title a h1' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'title_typography',
					'selector' => '{{WRAPPER}} .service-carousel-section .service-carousel-title a h1',
				]
			);
			$this->add_control(
				'heading_description',
				[
					'label' => __( 'Description css', 'elementor-webtheme' ),
					'type' => Controls_Manager::HEADING,
					'separator' => 'before',
				]
			);
			$this->add_control(
				'description_color',
				[
					'label' => __( 'Description Color', 'elementor-webtheme' ),
					'type' => Controls_Manager::COLOR,
					'default' => '',
					'selectors' => [
						'{{WRAPPER}} .service-carousel-section .service-carousel-desc p' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				\Elementor\Group_Control_Typography::get_type(),
				[
					'name' => 'description_typography',
					'selector' => '{{WRAPPER}} .service-carousel-section .service-carousel-desc p',
				]
			);
		$this->end_controls_section();
		
	}
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slides = isset($settings['slides']) ? $settings['slides'] : '';
		$this->add_render_attribute( 'title_text', 'class', 'service-box-title' );
		$this->add_render_attribute( 'description_text', 'class', 'service-box-desc' );
		?>
		<?php if($settings['select_option']=='one'){ ?>
			<section class="service-cursousel-slider">
			<?php foreach ($slides as $slide) { 
				$this->add_render_attribute( 'i', 'class', $slide['icon'] );
				$this->add_render_attribute( 'j', 'class', $slide['button_icon'] );
			?>
				<div class="service-carousel-section">		
					<div class="service-carousel-img">
						<img src="<?php echo $slide['select_img']['url'] ?>" alt="">
					</div>
					<div class="service-carousel-content">
						<div class="service-carousel-title">
							<a href="#"><h1><?php echo $slide['title_text']; ?></h1></a>
						</div>
						<div class="service-carousel-desc">
							<p><?php echo $slide['description_text']; ?></p>
						</div>
					</div>
					<?php if( 'yes'===$slide['show_button'] ){ ?>
					<div class="service-carousel-button">
						<a href="<?php echo esc_url($slide['link']['url']); ?>">
							<?php echo $slide['button_text']; ?>
							<?php \Elementor\Icons_Manager::render_icon( $slide['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
						</a>
					</div>
					<?php }?>
				</div>
			<?php } ?>
		</section>
            <script>
	                jQuery(document).ready(function() {
	                    jQuery(".service-cursousel-slider").slick({
	                        <?php
	                        if(is_rtl()) { ?>
	                            dots: false,
	                            infinite: true,
	                            autoplay: true,
	                            autoplaySpeed: 7000,
	                            centerPadding: '0',
								margin:30,
	                            arrows: true,
								prevArrow:
									'<span class="slick-prev"><i class="bi bi-chevron-right"></i></span>',
								nextArrow:
									'<span class="slick-next"><i class="bi bi-chevron-left"></i></span>',
								cssEase: "ease",
	                        <?php }else { ?>
	                            dots: false,
	                            infinite: true,
	                            autoplay: true,
	                            autoplaySpeed: 7000,
	                            slidesToShow: 4,
	                            slidesToScroll: 4,
	                            centerPadding: '0',
								margin:30,
								arrows: true,
								prevArrow:
									'<span class="slick-prev"><i aria-hidden="true" class="flaticon flaticon-back"></i></span>',
								nextArrow:
									'<span class="slick-next"><i aria-hidden="true" class="flaticon flaticon-next"></i></span>',
								cssEase: "ease",
								responsive: [
											{
												breakpoint: 1400,
												settings: {
													slidesToShow: 3,
												},
											},
											{
												breakpoint: 1170,
												settings: {
													slidesToShow: 2,
												},
											},
											{
												breakpoint: 991,
												settings: {
													slidesToShow: 2,
												},
											},
											{
												breakpoint: 700,
												settings: {
													slidesToShow: 1,
												},
											},
											{
												breakpoint: 600,
												settings: {
													slidesToShow: 1,
												},
											},
											
										],

	                        <?php } ?>
	                    });
	                });
	            </script>
		<?php }elseif($settings['select_option']=='two'){ ?>
	<section class="service-cursousel-slider2">
		<?php foreach ($slides as $slide) { 
			$this->add_render_attribute( 'i', 'class', $slide['icon'] );
			$this->add_render_attribute( 'j', 'class', $slide['button_icon'] );
		?>
			<div class="service-carousel-section option2">		
				<div class="service-carousel-img">
					<img src="<?php echo $slide['select_img']['url'] ?>" alt="">
				</div>
				<div class="service-carousel-content">
					<div class="service-carousel-title">
						<a href="#"><h1><?php echo $slide['title_text']; ?></h1></a>
					</div>
					<div class="service-carousel-desc">
						<p><?php echo $slide['description_text']; ?></p>
					</div>
				</div>
				<?php if( 'yes'===$slide['show_button'] ){ ?>
				<div class="service-carousel-button">
					<a href="<?php echo esc_url($slide['link']['url']); ?>">
						<?php echo $slide['button_text']; ?>
						<?php \Elementor\Icons_Manager::render_icon( $slide['button_icon'], [ 'aria-hidden' => 'true' ] ); ?>
					</a>
				</div>
				<?php }?>
			</div>
		<?php } ?>
	</section>
		<script>
			jQuery(document).ready(function() {
				jQuery(".service-cursousel-slider2").slick({
					<?php
					if(is_rtl()) { ?>
						dots: false,
						infinite: true,
						autoplay: true,
						autoplaySpeed: 7000,
						centerPadding: '0',
						margin:30,
						arrows: true,
						prevArrow:
							'<span class="slick-prev"><i class="bi bi-chevron-right"></i></span>',
						nextArrow:
							'<span class="slick-next"><i class="bi bi-chevron-left"></i></span>',
						cssEase: "ease",
					<?php }else { ?>
						dots: false,
						infinite: true,
						autoplay: true,
						autoplaySpeed: 7000,
						slidesToShow: 4,
						slidesToScroll: 4,
						centerPadding: '0',
						margin:30,
						arrows: true,
						prevArrow:
							'<span class="slick-prev"><i aria-hidden="true" class="flaticon flaticon-back"></i></span>',
						nextArrow:
							'<span class="slick-next"><i aria-hidden="true" class="flaticon flaticon-next"></i></span>',
						cssEase: "ease",
						responsive: [
									{
										breakpoint: 1400,
										settings: {
											slidesToShow: 3,
										},
									},
									{
										breakpoint: 1170,
										settings: {
											slidesToShow: 2,
										},
									},
									{
										breakpoint: 991,
										settings: {
											slidesToShow: 2,
										},
									},
									{
										breakpoint: 700,
										settings: {
											slidesToShow: 1,
										},
									},
									{
										breakpoint: 600,
										settings: {
											slidesToShow: 1,
										},
									},
									
								],
					<?php } ?>
				});
			});
		</script>
		<?php }?>
		<?php
	}
}