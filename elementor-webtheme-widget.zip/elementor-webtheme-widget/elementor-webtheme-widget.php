<?php
/**
 * Plugin Name: Elementor WebTheme Widget
 * Description: WebTheme Plugin custom widgets for our project. You can use it's easily.
 * Plugin URI:  https://elementor.com/
 * Version:     1.0.0
 * Author:      WebTheme
 * Author URI: https://elementor.com/
 * Text Domain: elementor-webtheme-widget
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

// Require once the Composer Autoload
if(file_exists(dirname(__FILE__).'/vendor/autoload.php')){
	require_once dirname(__FILE__).'/vendor/autoload.php';
}
// /*
// 	Plugin admin bar menu name add
//  */

//  function webtheme_add_theme_page(){

// 	add_menu_page(
// 		'webtheme Option for Admin', 'webtheme Plugin', 'manage_options', 'webtheme-plugin-option', 'webtheme_create_pagecds',
// 		'dashicons-unlock', 101
// 	);

//  }
// add_action('admin_menu', 'webtheme_add_theme_page');


/**
 * The main class that initiates and runs the plugin.
 * @since 1.0.0
 */
final class Elementor_Webtheme_Extension {

	/**
	 * Plugin Version
	 * @since 1.0.0
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 * @since 1.0.0
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 * @since 1.0.0
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '7.0';

	/**
	 * Instance
	 * @since 1.0.0
	 * @access private
	 * @static
	 * @var Elementor_Webtheme_Extension The single instance of the class.
	 */
	private static $_instance = null;

	/**
	 * Instance
	 * Ensures only one instance of the class is loaded or can be loaded.
	 * @since 1.0.0
	 * @access public
	 * @static
	 * @return Elementor_Webtheme_Extension An instance of the class.
	 */
	public static function instance() {
		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}
		return self::$_instance;
	}

	/**
	 * Constructor
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {

		add_action( 'init', [ $this, 'i18n' ] );
		add_action( 'plugins_loaded', [ $this, 'init' ] );
	}

	/**
	 * Load Textdomain
	 * Load plugin localization files.
	 * Fired by `init` action hook.
	 * @since 1.0.0
	 * @access public
	 */
	public function i18n() {

		load_plugin_textdomain( 'elementor-webtheme-widget' );

	}

	/**
	 * Initialize the plugin
	 * Load the plugin only after Elementor (and other plugins) are loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed load the files required to run the plugin.
	 * Fired by `plugins_loaded` action hook.
	 * 
	 * @since 1.0.0
	 * @access public
	 */
	public function init() {

		// Check if Elementor installed and activated
		if ( ! did_action( 'elementor/loaded' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );
			return;
		}

		// Check for required Elementor version
		if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );
			return;
		}

		// Check for required PHP version
		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
			add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );
			return;
		}
		
		//this add_action do link widget css and js editor
		//add_action( 'elementor/editor/after_enqueue_styles', [ $this, 'webtheme_widget_style' ] );

		add_action( 'elementor/frontend/after_enqueue_styles', [ $this, 'webtheme_widget_style_css_js' ] );
		//add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'webtheme_widget_scripts' ] );

		// Add Plugin actions
		add_action( 'elementor/widgets/widgets_registered', [ $this, 'init_widgets' ] );

		add_action( 'elementor/controls/controls_registered', [ $this, 'init_controls' ] );

        // Category Init
		add_action( 'elementor/init', [ $this, 'elementor_webtheme_category' ] );

	}

	/**
	 * Admin notice
	 * Warning when the site doesn't have Elementor installed or activated.
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_missing_main_plugin() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'elementor-webtheme-widget' ),
			'<strong>' . esc_html__( 'Elementor webtheme', 'elementor-webtheme-widget' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'elementor-webtheme-widget' ) . '</strong>'
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
	}

	/**
	 * Admin notice
	 * Warning when the site doesn't have a minimum required Elementor version.
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'elementor-webtheme-widget' ),
			'<strong>' . esc_html__( 'Elementor webtheme', 'elementor-webtheme-widget' ) . '</strong>',
			'<strong>' . esc_html__( 'Elementor', 'elementor-webtheme-widget' ) . '</strong>',
			 self::MINIMUM_ELEMENTOR_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Admin notice
	 * Warning when the site doesn't have a minimum required PHP version.
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_minimum_php_version() {

		if ( isset( $_GET['activate'] ) ) unset( $_GET['activate'] );

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'elementor-webtheme-widget' ),
			'<strong>' . esc_html__( 'Elementor webtheme', 'elementor-webtheme-widget' ) . '</strong>',
			'<strong>' . esc_html__( 'PHP', 'elementor-webtheme-widget' ) . '</strong>',
			 self::MINIMUM_PHP_VERSION
		);

		printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );

	}

	/**
	 * Init Controls
	 * Include controls files and register them
	 * @since 1.0.0
	 * @access public
	 */
	public function init_controls() {

	}
	
	/**
	 * Init Widgets
	 * Include widgets files and register them
	 * @since 1.0.0
	 * @access public
	 */
	public function init_widgets() {

		/*  Include Widgets files here     */
		require_once( __DIR__ . '/widgets/accordion-section.php' );
		require_once( __DIR__ . '/widgets/animation-marque.php' );
		require_once( __DIR__ . '/widgets/banner-section.php' );
		require_once( __DIR__ . '/widgets/banner-two-section.php' );
		require_once( __DIR__ . '/widgets/blog-post-section.php' );
		require_once( __DIR__ . '/widgets/button-section.php' );
		require_once( __DIR__ . '/widgets/brand-section.php' );
		require_once( __DIR__ . '/widgets/call-to-action.php' );
		require_once( __DIR__ . '/widgets/case-study-post-type.php' );
		require_once( __DIR__ . '/widgets/circle-progress.php' );
		require_once( __DIR__ . '/widgets/counter-section.php' );
		require_once( __DIR__ . '/widgets/feature-box.php' );
		require_once( __DIR__ . '/widgets/flip-box.php' );
		require_once( __DIR__ . '/widgets/heading-title.php' );
		require_once( __DIR__ . '/widgets/icon-box-section.php' );
		require_once( __DIR__ . '/widgets/icon-list-section.php' );
		require_once( __DIR__ . '/widgets/image-carousel-section.php' );
		require_once( __DIR__ . '/widgets/pricing-section.php' );
		require_once( __DIR__ . '/widgets/last-post-section.php' );
		require_once( __DIR__ . '/widgets/portfolio-post-type.php' );
		require_once( __DIR__ . '/widgets/section-title.php' );
		require_once( __DIR__ . '/widgets/service-carousel.php' );
		require_once( __DIR__ . '/widgets/service-section.php' );
		require_once( __DIR__ . '/widgets/shortcode-mail.php' );
		require_once( __DIR__ . '/widgets/social-media-section.php' );
		require_once( __DIR__ . '/widgets/team-section.php' );
		require_once( __DIR__ . '/widgets/team-slide-section.php' );
		require_once( __DIR__ . '/widgets/testimonial-section.php' );
		require_once( __DIR__ . '/widgets/video-box-section.php' );
		require_once( __DIR__ . '/widgets/work-system-section.php' );
		
	/*  widgets Register here     */
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \AccordionSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \AnimationMarque() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BannerSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BannerTwoSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BlogPostSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \ButtonSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \BrandSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CallToAction() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CaseStudyPostType() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CircleProgress() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \CounterSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FeatureBoxSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \FlipBoxSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \HeadingTitle() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \IconBoxSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \IconListSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \ImagecarouselSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \PricingSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \LastPostSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \PortfolioPostType() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \SectionTitles() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \Servicecarousel() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \ServiceSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \ShortcodeMail() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \SocialMediaSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \TeamSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \TeamSlideSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \TestimonialSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \VideoBoxSection() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new \WorkSystemSection() );
	}

	// Custom CSS Links 
	public function webtheme_widget_style_css_js() {
		//wp_register_style( 'widget-style', plugins_url( 'assets/css/section-style.css', __FILE__ ) );
		//wp_enqueue_style('widget-style');
		//if you neet to new css link please link: css-js-link.php
		require webtheme_DIR_PATH . 'css-js-link.php';
    // Custom JS links css-js-link.php
		// wp_register_script( 'elementor-common-js', plugins_url( 'main.js', __FILE__ ) );
		// wp_enqueue_script('elementor-common-js');

	}

    // Custom Category elementor widgets
    public function elementor_webtheme_category () {

	   \Elementor\Plugin::$instance->elements_manager->add_category( 
	   	'elementor-webtheme-category',
			[
				'title' => __( 'WebTheme Elementor Widgets', 'elementor-webtheme-widget' ),
				'icon' => 'fa fa-plug', //default icon
			],
	   );
	}
}

Elementor_Webtheme_Extension::instance();
define( 'webtheme_DIR_PATH', plugin_dir_path( __FILE__ ) );

require webtheme_DIR_PATH . 'post-type/case-study-post-type.php';
require webtheme_DIR_PATH . 'post-type/portfolio-post-type.php';
require webtheme_DIR_PATH . 'include/flaticons/icons.php';
require webtheme_DIR_PATH . 'include/flaticons/flaticon/icons.php';
