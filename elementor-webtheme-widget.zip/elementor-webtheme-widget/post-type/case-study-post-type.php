<?php
	// Case Study post type 
	function webtheme_case_study_post_type() 
	{
		$labels = array(
			'name'               => _x( 'Case Study', 'post type general name', 'webtheme' ),
			'singular_name'      => _x( 'Case Study', 'post type singular name', 'webtheme' ),
			'menu_name'          => _x( 'Case Study', 'admin menu', 'webtheme' ),
			'name_admin_bar'     => _x( 'Case Study', 'add new on admin bar', 'webtheme' ),
			'add_new'            => _x( 'Add New', 'Case Study', 'webtheme' ),
			'add_new_item'       => __( 'Add New Case Study', 'webtheme' ),
			'new_item'           => __( 'New Case Study', 'webtheme' ),
			'edit_item'          => __( 'Edit Case Study', 'webtheme' ),
			'view_item'          => __( 'View Case Study', 'webtheme' ),
			'all_items'          => __( 'All Case Study', 'webtheme' ),
			'search_items'       => __( 'Search Case Study', 'webtheme' ),
			'parent_item_colon'  => __( 'Parent Case Study:', 'webtheme' ),
			'not_found'          => __( 'No Case Study found.', 'webtheme' ),
			'not_found_in_trash' => __( 'No Case Study found in Trash.', 'webtheme' )
		);
		$args = array(
			'labels'             => $labels,
			'public'             => true,
			'menu_icon'          =>'dashicons-images-alt',		
			'exclude_from_search'=> true,
			'show_ui'            => true,
			'show_in_menu'       => true,
			'query_var'          => true,
			'rewrite'            => array( 'slug' => 'case_study_post' ),
			'capability_type'    => 'post',
			'has_archive'        => true,
			'hierarchical'       => false,
			'menu_position'      => null,
			'supports'           => array('title','editor', 'thumbnail')
		);
		
		register_post_type( 'case_study_post' , $args );
		
		$labels = array(
			'name'              => _x( 'Categories', 'taxonomy general name', 'webtheme' ),
			'singular_name'     => _x( 'Category', 'taxonomy singular name', 'webtheme' ),
			'search_items'      => __( 'Search Categories', 'webtheme' ),
			'all_items'         => __( 'All Categories', 'webtheme' ),
			'parent_item'       => __( 'Parent Category', 'webtheme' ),
			'parent_item_colon' => __( 'Parent Category:', 'webtheme' ),
			'edit_item'         => __( 'Edit Category', 'webtheme' ),
			'update_item'       => __( 'Update Category', 'webtheme' ),
			'add_new_item'      => __( 'Add New Category', 'webtheme' ),
			'new_item_name'     => __( 'New Category Name', 'webtheme' ),
			'menu_name'         => __( 'Categories', 'webtheme' ),
		);

		$args = array(
			'public'            => false,
			'hierarchical'      => true,
			'labels'            => $labels,
			'show_ui'           => true,
			'show_admin_column' => true,
			'show_in_nav_menus' => false,
			'query_var'         => false,
			'rewrite'           => array( 'slug' => 'casestudy-category' ),  
		);
		
		register_taxonomy( 'case_study_post_category', array( 'case_study_post' ), $args );
	}
	add_action( 'init', 'webtheme_case_study_post_type' );